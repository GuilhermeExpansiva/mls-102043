declare module "_102043_/l1/cafeFlow/layer_1_external/aiInsightRequest.defs" {
    export const aiInsightRequestTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "aiInsightRequest";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 49;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "aiInsightRequest";
                readonly tableName: "ai_insight_request";
                readonly moduleId: "cafeFlow";
                readonly title: "Solicitações de insight IA";
                readonly purpose: "Rastrear solicitações e resultados do assistente IA usando métricas consolidadas.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "AiInsightRequest";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "ai_insight_request_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único da solicitação de insight IA.";
                }, {
                    readonly name: "insight_type";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Tipo de insight solicitado.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Status atual da solicitação de insight.";
                }, {
                    readonly name: "daily_shift_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Referência ao turno do dia relacionado à solicitação.";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação da solicitação.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização da solicitação.";
                }];
                readonly primaryKey: readonly ["ai_insight_request_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "daily_shift_id";
                    readonly targetEntity: "DailyShift";
                    readonly targetOwnership: "moduleOwned";
                    readonly reason: "Solicitação pode estar vinculada a um turno específico.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_ai_insight_request_status";
                    readonly columns: readonly ["status"];
                    readonly unique: false;
                    readonly reason: "Filtrar solicitações por status no fluxo de geração.";
                }, {
                    readonly indexName: "idx_ai_insight_request_created_at";
                    readonly columns: readonly ["created_at"];
                    readonly unique: false;
                    readonly reason: "Filtrar por período para relatórios e auditoria.";
                }, {
                    readonly indexName: "idx_ai_insight_request_daily_shift_id";
                    readonly columns: readonly ["daily_shift_id"];
                    readonly unique: false;
                    readonly reason: "Consultar solicitações por turno.";
                }, {
                    readonly indexName: "idx_ai_insight_request_insight_type";
                    readonly columns: readonly ["insight_type"];
                    readonly unique: false;
                    readonly reason: "Filtrar por tipo de insight solicitado.";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["aiInsightsUseMetrics"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/aiInsightRequest.defs.ts";
                readonly exportName: "aiInsightRequestTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default aiInsightRequestTableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/dailySalesMetrics.defs" {
    export const dailySalesMetricsMetricTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "dailySalesMetrics";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 56;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "dailySalesMetrics";
                readonly tableName: "daily_sales_metrics";
                readonly moduleId: "cafeFlow";
                readonly title: "Tabela de métricas: Vendas do dia";
                readonly purpose: "Consolidar métricas de vendas por turno e período.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_time";
                readonly columns: readonly [{
                    readonly name: "event_time";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Momento do evento agregado para a métrica.";
                }, {
                    readonly name: "shift_id";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Identificador do turno diário.";
                }, {
                    readonly name: "order_id";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Identificador do pedido.";
                }, {
                    readonly name: "menu_item_id";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Identificador do item do cardápio.";
                }, {
                    readonly name: "category_id";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Identificador da categoria do cardápio.";
                }, {
                    readonly name: "order_item_id";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "FK dimension derived from ontology relationship orderToOrderItem (Order -> OrderItem)";
                }, {
                    readonly name: "daily_shift_id";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "FK dimension derived from ontology relationship orderToDailyShift (Order -> DailyShift)";
                }, {
                    readonly name: "shift_closing_report_id";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "FK dimension derived from ontology relationship shiftToClosingReport (DailyShift -> ShiftClosingReport)";
                }, {
                    readonly name: "total_revenue";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Receita total gerada.";
                }, {
                    readonly name: "order_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade de pedidos.";
                }, {
                    readonly name: "items_sold";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade total de itens vendidos.";
                }, {
                    readonly name: "average_ticket";
                    readonly type: "numeric";
                    readonly nullable: true;
                    readonly description: "Ticket médio por pedido.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "shiftId";
                    readonly column: "shift_id";
                    readonly type: "string";
                    readonly description: "Identificador do turno diário.";
                }, {
                    readonly dimensionId: "orderId";
                    readonly column: "order_id";
                    readonly type: "string";
                    readonly description: "Identificador do pedido.";
                }, {
                    readonly dimensionId: "menuItemId";
                    readonly column: "menu_item_id";
                    readonly type: "string";
                    readonly description: "Identificador do item do cardápio.";
                }, {
                    readonly dimensionId: "categoryId";
                    readonly column: "category_id";
                    readonly type: "string";
                    readonly description: "Identificador da categoria do cardápio.";
                }, {
                    readonly dimensionId: "orderItemId";
                    readonly column: "order_item_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship orderToOrderItem (Order -> OrderItem)";
                }, {
                    readonly dimensionId: "dailyShiftId";
                    readonly column: "daily_shift_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship orderToDailyShift (Order -> DailyShift)";
                }, {
                    readonly dimensionId: "shiftClosingReportId";
                    readonly column: "shift_closing_report_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship shiftToClosingReport (DailyShift -> ShiftClosingReport)";
                }];
                readonly measures: readonly [{
                    readonly measureId: "totalRevenue";
                    readonly column: "total_revenue";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Receita total gerada.";
                }, {
                    readonly measureId: "orderCount";
                    readonly column: "order_count";
                    readonly aggregation: "count";
                    readonly unit: "orders";
                    readonly description: "Quantidade de pedidos.";
                }, {
                    readonly measureId: "itemsSold";
                    readonly column: "items_sold";
                    readonly aggregation: "sum";
                    readonly unit: "items";
                    readonly description: "Quantidade total de itens vendidos.";
                }, {
                    readonly measureId: "averageTicket";
                    readonly column: "average_ticket";
                    readonly aggregation: "avg";
                    readonly unit: "BRL";
                    readonly description: "Ticket médio por pedido.";
                }];
                readonly sourceWriteEvents: readonly ["orderCreated", "orderItemAdded", "orderStatusUpdated", "shiftClosed"];
                readonly hypertable: {
                    readonly timeColumn: "event_time";
                    readonly chunkTimeInterval: "1 day";
                    readonly retentionPolicy: "1 year";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_daily_sales_metrics_event_time_shift";
                        readonly columns: readonly ["event_time", "shift_id"];
                        readonly purpose: "Consultas por período e turno.";
                    }, {
                        readonly indexName: "idx_daily_sales_metrics_order_id";
                        readonly columns: readonly ["order_id", "event_time"];
                        readonly purpose: "Consulta por pedido no recorte temporal.";
                    }, {
                        readonly indexName: "idx_daily_sales_metrics_menu_item_id";
                        readonly columns: readonly ["menu_item_id", "event_time"];
                        readonly purpose: "Consultas por item do cardápio ao longo do tempo.";
                    }, {
                        readonly indexName: "idx_daily_sales_metrics_category_id";
                        readonly columns: readonly ["category_id", "event_time"];
                        readonly purpose: "Consultas por categoria ao longo do tempo.";
                    }, {
                        readonly indexName: "idx_daily_sales_metrics_daily_shift_id";
                        readonly columns: readonly ["daily_shift_id", "event_time"];
                        readonly purpose: "Consultas por turno diário ao longo do tempo.";
                    }, {
                        readonly indexName: "idx_daily_sales_metrics_order_item_id";
                        readonly columns: readonly ["order_item_id", "event_time"];
                        readonly purpose: "Consultas por item do pedido ao longo do tempo.";
                    }, {
                        readonly indexName: "idx_daily_sales_metrics_shift_closing_report_id";
                        readonly columns: readonly ["shift_closing_report_id", "event_time"];
                        readonly purpose: "Consultas por relatório de fechamento ao longo do tempo.";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["orderStatusLifecycle", "shiftCloseRequiresOrders"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/dailySalesMetrics.defs.ts";
                readonly exportName: "dailySalesMetricsMetricTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default dailySalesMetricsMetricTableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/dailyShift.defs" {
    export const dailyShiftTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "dailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 53;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "dailyShift";
                readonly tableName: "daily_shift";
                readonly moduleId: "cafeFlow";
                readonly title: "Turnos diários";
                readonly purpose: "Controlar abertura e fechamento de turno e consolidar relatório do dia.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "DailyShift";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "daily_shift_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do turno diário.";
                }, {
                    readonly name: "shift_date";
                    readonly type: "date";
                    readonly nullable: false;
                    readonly description: "Data do turno diário.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Status do turno diário (aberto/fechado).";
                }, {
                    readonly name: "opened_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de abertura do turno.";
                }, {
                    readonly name: "closed_at";
                    readonly type: "datetime";
                    readonly nullable: true;
                    readonly description: "Data e hora de fechamento do turno.";
                }, {
                    readonly name: "opening_cash_amount";
                    readonly type: "money";
                    readonly nullable: true;
                    readonly description: "Valor de caixa informado na abertura do turno.";
                }, {
                    readonly name: "closing_cash_amount";
                    readonly type: "money";
                    readonly nullable: true;
                    readonly description: "Valor de caixa informado no fechamento do turno.";
                }, {
                    readonly name: "total_sales_amount";
                    readonly type: "money";
                    readonly nullable: true;
                    readonly description: "Total de vendas consolidadas no turno.";
                }, {
                    readonly name: "total_orders";
                    readonly type: "number";
                    readonly nullable: true;
                    readonly description: "Quantidade total de pedidos no turno.";
                }, {
                    readonly name: "notes";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Observações gerais do turno.";
                }, {
                    readonly name: "shift_closing_report_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Referência ao relatório de fechamento do turno.";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização do registro.";
                }, {
                    readonly name: "details";
                    readonly type: "jsonb";
                    readonly nullable: false;
                    readonly description: "Dados agregados do relatório de fechamento e outros detalhes do turno.";
                }];
                readonly primaryKey: readonly ["daily_shift_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "shift_closing_report_id";
                    readonly targetEntity: "ShiftClosingReport";
                    readonly targetOwnership: "moduleOwned";
                    readonly reason: "Vincular o relatório de fechamento ao turno diário.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_daily_shift_date";
                    readonly columns: readonly ["shift_date"];
                    readonly unique: false;
                    readonly reason: "Filtro por data no dashboard.";
                }, {
                    readonly indexName: "idx_daily_shift_status";
                    readonly columns: readonly ["status"];
                    readonly unique: false;
                    readonly reason: "Consulta de turno aberto/fechado para validações de fluxo.";
                }, {
                    readonly indexName: "idx_daily_shift_opened_at";
                    readonly columns: readonly ["opened_at"];
                    readonly unique: false;
                    readonly reason: "Ordenação e filtros por período de abertura.";
                }, {
                    readonly indexName: "idx_daily_shift_closed_at";
                    readonly columns: readonly ["closed_at"];
                    readonly unique: false;
                    readonly reason: "Filtro por período de fechamento no relatório.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly reason: "Armazenar o relatório de fechamento e dados agregados como JSON.";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly [];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["shiftMustBeOpenForOrders", "shiftCloseRequiresOrders"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/dailyShift.defs.ts";
                readonly exportName: "dailyShiftTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default dailyShiftTableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/inventoryAdjustment.defs" {
    export const inventoryAdjustmentTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "inventoryAdjustment";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 50;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "inventoryAdjustment";
                readonly tableName: "inventory_adjustment";
                readonly title: "Ajustes de estoque";
                readonly purpose: "Registrar ajustes de estoque com status de confirmação.";
                readonly moduleId: "cafeFlow";
                readonly ownership: "moduleOwned";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly rootEntity: "InventoryAdjustment";
                readonly primaryKey: readonly ["inventory_adjustment_id"];
                readonly columns: readonly [{
                    readonly name: "inventory_adjustment_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do ajuste de estoque.";
                }, {
                    readonly name: "inventory_item_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Item de estoque ao qual o ajuste se aplica.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Status do ajuste de estoque.";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização do registro.";
                }];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "inventory_item_id";
                    readonly targetEntity: "InventoryItem";
                    readonly targetOwnership: "moduleOwned";
                    readonly reason: "Referência ao item de estoque ajustado.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_inventory_adjustment_item_id";
                    readonly columns: readonly ["inventory_item_id"];
                    readonly reason: "Lookup por item de estoque para listar ajustes.";
                    readonly unique: false;
                }, {
                    readonly indexName: "idx_inventory_adjustment_status";
                    readonly columns: readonly ["status"];
                    readonly reason: "Filtragem por status do ajuste.";
                    readonly unique: false;
                }, {
                    readonly indexName: "idx_inventory_adjustment_created_at";
                    readonly columns: readonly ["created_at"];
                    readonly reason: "Ordenação e filtragem por data de criação.";
                    readonly unique: false;
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly metricRefs: readonly [];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["inventoryDecrementPolicy", "inventoryLowStockAlert"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/inventoryAdjustment.defs.ts";
                readonly exportName: "inventoryAdjustmentTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default inventoryAdjustmentTableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/inventoryItem.defs" {
    export const inventoryItemTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "inventoryItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 50;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "inventoryItem";
                readonly tableName: "inventory_item";
                readonly moduleId: "cafeFlow";
                readonly title: "Itens de estoque";
                readonly purpose: "Controlar estoque básico e níveis para alertas e baixa de insumos.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "InventoryItem";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "inventory_item_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do item de estoque.";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Nome do insumo ou item de estoque.";
                }, {
                    readonly name: "quantity_available";
                    readonly type: "number";
                    readonly nullable: false;
                    readonly description: "Quantidade disponível em estoque.";
                }, {
                    readonly name: "minimum_level";
                    readonly type: "number";
                    readonly nullable: false;
                    readonly description: "Nível mínimo aceitável para o estoque.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly default: "active";
                    readonly description: "Status do item de estoque (ex.: active, inactive).";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização do registro.";
                }];
                readonly primaryKey: readonly ["inventory_item_id"];
                readonly foreignRefs: readonly [];
                readonly indexes: readonly [{
                    readonly indexName: "idx_inventory_item_name";
                    readonly columns: readonly ["name"];
                    readonly unique: false;
                    readonly reason: "Busca por nome no gerenciamento de estoque.";
                }, {
                    readonly indexName: "idx_inventory_item_low_stock";
                    readonly columns: readonly ["quantity_available", "minimum_level"];
                    readonly unique: false;
                    readonly reason: "Filtrar itens abaixo do nível mínimo no dashboard.";
                }, {
                    readonly indexName: "idx_inventory_item_status";
                    readonly columns: readonly ["status"];
                    readonly unique: false;
                    readonly reason: "Filtrar itens ativos/inativos no gerenciamento.";
                }, {
                    readonly indexName: "idx_inventory_item_updated_at";
                    readonly columns: readonly ["updated_at"];
                    readonly unique: false;
                    readonly reason: "Ordenação e filtros por data para relatórios/turno.";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly metricRefs: readonly ["inventoryLowStockAlert"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["inventoryLowStockAlert", "inventoryDecrementPolicy"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/inventoryItem.defs.ts";
                readonly exportName: "inventoryItemTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default inventoryItemTableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/lowStockMetrics.defs" {
    export const lowStockMetricsMetricTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "lowStockMetrics";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 58;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "lowStockMetrics";
                readonly tableName: "low_stock_metrics";
                readonly moduleId: "cafeFlow";
                readonly title: "Tabela de métricas: Estoque baixo";
                readonly purpose: "Monitorar níveis de estoque e alertas de baixa quantidade.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_time";
                readonly columns: readonly [{
                    readonly name: "event_time";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data e hora do evento de métrica.";
                }, {
                    readonly name: "inventory_item_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Identificador do item de estoque.";
                }, {
                    readonly name: "menu_item_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Identificador do item do cardápio relacionado.";
                }, {
                    readonly name: "adjustment_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Identificador do ajuste de estoque.";
                }, {
                    readonly name: "current_quantity";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly description: "Quantidade atual em estoque.";
                }, {
                    readonly name: "threshold_quantity";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly description: "Quantidade mínima definida para alerta.";
                }, {
                    readonly name: "low_stock_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 1;
                    readonly description: "Contagem de ocorrências de estoque baixo.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "inventoryItemId";
                    readonly column: "inventory_item_id";
                    readonly type: "string";
                    readonly description: "Identificador do item de estoque.";
                }, {
                    readonly dimensionId: "menuItemId";
                    readonly column: "menu_item_id";
                    readonly type: "string";
                    readonly description: "Identificador do item do cardápio relacionado.";
                }, {
                    readonly dimensionId: "adjustmentId";
                    readonly column: "adjustment_id";
                    readonly type: "string";
                    readonly description: "Identificador do ajuste de estoque.";
                }];
                readonly measures: readonly [{
                    readonly measureId: "currentQuantity";
                    readonly column: "current_quantity";
                    readonly aggregation: "last";
                    readonly unit: "units";
                    readonly description: "Quantidade atual em estoque.";
                }, {
                    readonly measureId: "thresholdQuantity";
                    readonly column: "threshold_quantity";
                    readonly aggregation: "last";
                    readonly unit: "units";
                    readonly description: "Quantidade mínima definida para alerta.";
                }, {
                    readonly measureId: "lowStockCount";
                    readonly column: "low_stock_count";
                    readonly aggregation: "count";
                    readonly unit: "alerts";
                    readonly description: "Contagem de ocorrências de estoque baixo.";
                }];
                readonly sourceWriteEvents: readonly ["inventoryAdjusted", "inventoryItemUpdated"];
                readonly hypertable: {
                    readonly timeColumn: "event_time";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "6 months";
                    readonly compressionPolicy: "30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_low_stock_metrics_event_time";
                        readonly columns: readonly ["event_time"];
                        readonly purpose: "Ordenação e filtros por período.";
                    }, {
                        readonly indexName: "idx_low_stock_metrics_event_time_inventory_item";
                        readonly columns: readonly ["event_time", "inventory_item_id"];
                        readonly purpose: "Filtrar métricas de estoque por item e período.";
                    }, {
                        readonly indexName: "idx_low_stock_metrics_menu_item";
                        readonly columns: readonly ["menu_item_id"];
                        readonly purpose: "Filtrar métricas por item do cardápio relacionado.";
                    }, {
                        readonly indexName: "idx_low_stock_metrics_adjustment";
                        readonly columns: readonly ["adjustment_id"];
                        readonly purpose: "Rastrear métricas por ajuste de estoque.";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["gerenciarEstoque"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["inventoryLowStockAlert", "inventoryDecrementPolicy"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/lowStockMetrics.defs.ts";
                readonly exportName: "lowStockMetricsMetricTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default lowStockMetricsMetricTableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/menuCategory.defs" {
    export const menuCategoryTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "menuCategory";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 49;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "menuCategory";
                readonly tableName: "menu_category";
                readonly moduleId: "cafeFlow";
                readonly title: "Categorias do cardápio";
                readonly purpose: "Organizar itens do cardápio por categoria para gestão e exibição no POS.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "MenuCategory";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "menu_category_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único da categoria";
                }, {
                    readonly name: "name";
                    readonly type: "varchar";
                    readonly nullable: false;
                    readonly description: "Nome da categoria exibido no POS";
                }, {
                    readonly name: "description";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Descrição opcional da categoria";
                }, {
                    readonly name: "sort_order";
                    readonly type: "int";
                    readonly nullable: true;
                    readonly description: "Ordem de exibição no POS (menor valor aparece primeiro)";
                }, {
                    readonly name: "color";
                    readonly type: "varchar";
                    readonly nullable: true;
                    readonly description: "Cor hexadecimal para identificação visual no POS";
                }, {
                    readonly name: "is_active";
                    readonly type: "boolean";
                    readonly nullable: false;
                    readonly default: true;
                    readonly description: "Indica se a categoria está ativa e visível no cardápio";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação do registro";
                }, {
                    readonly name: "updated_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização do registro";
                }];
                readonly primaryKey: readonly ["menu_category_id"];
                readonly foreignRefs: readonly [];
                readonly indexes: readonly [{
                    readonly indexName: "idx_menu_category_name";
                    readonly columns: readonly ["name"];
                    readonly unique: false;
                    readonly reason: "Busca por nome na gestão do cardápio";
                }, {
                    readonly indexName: "idx_menu_category_active_sort";
                    readonly columns: readonly ["is_active", "sort_order"];
                    readonly unique: false;
                    readonly reason: "Ordenação e filtragem de categorias ativas no POS";
                }, {
                    readonly indexName: "idx_menu_category_created_at";
                    readonly columns: readonly ["created_at"];
                    readonly unique: false;
                    readonly reason: "Filtros por data em relatórios e auditoria";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                    readonly reason: "Campos estruturados suficientes para filtros e exibição no POS";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: false;
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly [];
            };
            readonly defsPlan: {
                readonly fileName: "tables/menuCategory.defs.ts";
                readonly exportName: "menuCategoryTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default menuCategoryTableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/menuItemIngredient.defs" {
    export const menuItemIngredientTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "menuItemIngredient";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 51;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "menuItemIngredient";
                readonly tableName: "menu_item_ingredient";
                readonly moduleId: "cafeFlow";
                readonly title: "Ingredientes por item do cardápio";
                readonly purpose: "Mapear insumos usados por item do cardápio para baixa e alerta de estoque.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "MenuItemIngredient";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do vínculo ingrediente-cardápio";
                }, {
                    readonly name: "menuItemId";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Referência ao item do cardápio";
                }, {
                    readonly name: "inventoryItemId";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Referência ao item de estoque utilizado como ingrediente";
                }, {
                    readonly name: "quantity";
                    readonly type: "number";
                    readonly nullable: false;
                    readonly description: "Quantidade necessária do ingrediente para o preparo do item";
                }, {
                    readonly name: "unit";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Unidade de medida (ex: g, ml, unidade, colher)";
                }, {
                    readonly name: "isOptional";
                    readonly type: "boolean";
                    readonly nullable: false;
                    readonly description: "Indica se o ingrediente é opcional ou pode ser removido do item";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly default: "active";
                    readonly description: "Status do vínculo ingrediente-cardápio";
                }, {
                    readonly name: "createdAt";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação do registro";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização do registro";
                }];
                readonly primaryKey: readonly ["id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "menuItemId";
                    readonly targetEntity: "MenuItem";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "rule:mdmOwned";
                }, {
                    readonly fieldName: "inventoryItemId";
                    readonly targetEntity: "InventoryItem";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "rule:mdmOwned";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_menu_item_ingredient_menu_item";
                    readonly columns: readonly ["menuItemId"];
                    readonly reason: "Consultas por item do cardápio";
                }, {
                    readonly indexName: "idx_menu_item_ingredient_inventory_item";
                    readonly columns: readonly ["inventoryItemId"];
                    readonly reason: "Consulta de uso por item de estoque";
                }, {
                    readonly indexName: "ux_menu_item_ingredient_menu_item_inventory_item";
                    readonly columns: readonly ["menuItemId", "inventoryItemId"];
                    readonly unique: true;
                    readonly reason: "Evitar duplicidade de vínculo por item e ingrediente";
                }, {
                    readonly indexName: "idx_menu_item_ingredient_status";
                    readonly columns: readonly ["status"];
                    readonly reason: "Filtragem por status";
                }, {
                    readonly indexName: "idx_menu_item_ingredient_created_at";
                    readonly columns: readonly ["createdAt"];
                    readonly reason: "Filtro temporal";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: false;
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["inventoryDecrementPolicy"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/menuItemIngredient.defs.ts";
                readonly exportName: "menuItemIngredientTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default menuItemIngredientTableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/order.defs" {
    export const orderTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "order";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 52;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "order";
                readonly tableName: "order";
                readonly moduleId: "cafeFlow";
                readonly title: "Pedidos";
                readonly purpose: "Registrar pedidos do POS com itens e status para cozinha e atendimento.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "Order";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "order_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do pedido.";
                }, {
                    readonly name: "daily_shift_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Referência ao turno diário ao qual o pedido pertence.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Status atual do pedido.";
                }, {
                    readonly name: "service_type";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Tipo de atendimento do pedido (mesa ou takeout).";
                }, {
                    readonly name: "table_number";
                    readonly type: "string";
                    readonly nullable: true;
                    readonly description: "Número/identificador da mesa quando o atendimento é em mesa.";
                }, {
                    readonly name: "notes";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Observações gerais do pedido.";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação do pedido.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização do pedido.";
                }];
                readonly primaryKey: readonly ["order_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "daily_shift_id";
                    readonly targetEntity: "DailyShift";
                    readonly targetOwnership: "existingModuleOwned";
                    readonly reason: "Turno diário necessário para validar criação do pedido.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_order_daily_shift_status";
                    readonly columns: readonly ["daily_shift_id", "status"];
                    readonly unique: false;
                    readonly reason: "Listagens operacionais por turno e status.";
                }, {
                    readonly indexName: "idx_order_created_at";
                    readonly columns: readonly ["created_at"];
                    readonly unique: false;
                    readonly reason: "Consultas por período para dashboard.";
                }, {
                    readonly indexName: "idx_order_status";
                    readonly columns: readonly ["status"];
                    readonly unique: false;
                    readonly reason: "Filtragem rápida por status de preparo.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly jsonSchemaRef: "OrderItemsDetails";
                    readonly reason: "Itens do pedido e observações de item são agregados e acessados junto ao pedido.";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly [];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["orderStatusLifecycle", "kitchenStatusUpdates", "shiftMustBeOpenForOrders"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/order.defs.ts";
                readonly exportName: "orderTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default orderTableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/topSellingItemsMetrics.defs" {
    export const topSellingItemsMetricsTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "topSellingItemsMetrics";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 57;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "topSellingItemsMetrics";
                readonly tableName: "top_selling_items_metrics";
                readonly moduleId: "cafeFlow";
                readonly title: "Tabela de métricas: Itens mais vendidos";
                readonly purpose: "Rastrear desempenho e popularidade dos itens do cardápio.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_time";
                readonly columns: readonly [{
                    readonly name: "event_time";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Timestamp do evento de venda/atualização usado para séries temporais.";
                }, {
                    readonly name: "menu_item_id";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Identificador do item do cardápio.";
                }, {
                    readonly name: "category_id";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Identificador da categoria do cardápio.";
                }, {
                    readonly name: "order_id";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Identificador do pedido.";
                }, {
                    readonly name: "menu_category_id";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "FK dimension derived from ontology relationship menuItemToCategory (MenuItem -> MenuCategory)";
                }, {
                    readonly name: "menu_item_ingredient_id";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "FK dimension derived from ontology relationship menuItemToIngredient (MenuItem -> MenuItemIngredient)";
                }, {
                    readonly name: "quantity_sold";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly description: "Quantidade vendida do item.";
                }, {
                    readonly name: "item_revenue";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly description: "Receita gerada pelo item.";
                }, {
                    readonly name: "order_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly description: "Número de pedidos que incluíram o item.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "menuItemId";
                    readonly column: "menu_item_id";
                    readonly type: "string";
                    readonly description: "Identificador do item do cardápio.";
                }, {
                    readonly dimensionId: "categoryId";
                    readonly column: "category_id";
                    readonly type: "string";
                    readonly description: "Identificador da categoria do cardápio.";
                }, {
                    readonly dimensionId: "orderId";
                    readonly column: "order_id";
                    readonly type: "string";
                    readonly description: "Identificador do pedido.";
                }, {
                    readonly dimensionId: "menuCategoryId";
                    readonly column: "menu_category_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship menuItemToCategory (MenuItem -> MenuCategory)";
                }, {
                    readonly dimensionId: "menuItemIngredientId";
                    readonly column: "menu_item_ingredient_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship menuItemToIngredient (MenuItem -> MenuItemIngredient)";
                }];
                readonly measures: readonly [{
                    readonly measureId: "quantitySold";
                    readonly column: "quantity_sold";
                    readonly aggregation: "sum";
                    readonly unit: "items";
                    readonly description: "Quantidade vendida do item.";
                }, {
                    readonly measureId: "itemRevenue";
                    readonly column: "item_revenue";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Receita gerada pelo item.";
                }, {
                    readonly measureId: "orderCount";
                    readonly column: "order_count";
                    readonly aggregation: "count";
                    readonly unit: "orders";
                    readonly description: "Número de pedidos que incluíram o item.";
                }];
                readonly sourceWriteEvents: readonly ["orderItemAdded", "orderStatusUpdated"];
                readonly hypertable: {
                    readonly timeColumn: "event_time";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "2 years";
                    readonly compressionPolicy: "30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_top_selling_items_metrics_event_time";
                        readonly columns: readonly ["event_time"];
                        readonly purpose: "Acelerar consultas por janela temporal.";
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_menu_item_time";
                        readonly columns: readonly ["menu_item_id", "event_time"];
                        readonly purpose: "Ranking temporal por item do cardápio.";
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_category_time";
                        readonly columns: readonly ["category_id", "event_time"];
                        readonly purpose: "Ranking temporal por categoria.";
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_order_id";
                        readonly columns: readonly ["order_id"];
                        readonly purpose: "Consulta por pedido específico.";
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_menu_category_id";
                        readonly columns: readonly ["menu_category_id"];
                        readonly purpose: "Filtro por categoria derivada.";
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_menu_item_ingredient_id";
                        readonly columns: readonly ["menu_item_ingredient_id"];
                        readonly purpose: "Filtro por ingrediente vinculado.";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["registrarPedidoPos", "atualizarStatusCozinha"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["orderStatusLifecycle", "kitchenStatusUpdates"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/topSellingItemsMetrics.defs.ts";
                readonly exportName: "topSellingItemsMetricsTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default topSellingItemsMetricsTableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/abrirTurno-commands.defs" {
    export const abrirTurnoCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "abrirTurno";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 59;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "abrirTurno";
                readonly commands: readonly [{
                    readonly commandId: "abrirTurno";
                    readonly input: readonly [{
                        readonly name: "turno";
                        readonly type: "TurnoEntity";
                        readonly required: true;
                    }];
                    readonly output: readonly [{
                        readonly name: "turno";
                        readonly type: "TurnoEntity";
                    }];
                }];
            };
        };
    };
    export default abrirTurnoCommands;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/abrirTurno.defs" {
    export const useCase: {
        readonly usecaseId: "abrirTurno";
        readonly title: "Abrir turno diário";
        readonly purpose: "Inicia um novo turno de vendas.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["TurnoEntity"];
        readonly outputEntities: readonly ["TurnoEntity"];
        readonly readsTables: readonly [];
        readonly writesTables: readonly [{
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["TurnoEntity"];
    };
    export default useCase;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/adicionarItemPedido-commands.defs" {
    export const adicionarItemPedidoCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "adicionarItemPedido";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 59;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "adicionarItemPedido";
                readonly commands: readonly [{
                    readonly commandId: "adicionarItemPedido";
                    readonly input: readonly [{
                        readonly name: "pedidoId";
                        readonly type: "string";
                        readonly required: true;
                    }, {
                        readonly name: "menuItemId";
                        readonly type: "string";
                        readonly required: true;
                    }, {
                        readonly name: "quantidade";
                        readonly type: "number";
                        readonly required: true;
                    }];
                    readonly output: readonly [{
                        readonly name: "pedido";
                        readonly type: "PedidoEntity";
                    }];
                }];
            };
        };
    };
    export default adicionarItemPedidoCommands;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/adicionarItemPedido.defs" {
    export const useCase: {
        readonly usecaseId: "adicionarItemPedido";
        readonly title: "Adicionar item ao pedido";
        readonly purpose: "Adiciona um item ao pedido existente e atualiza métricas de itens vendidos.";
        readonly actor: "atendenteCaixa";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["PedidoEntity"];
        readonly outputEntities: readonly ["PedidoEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "menu_item";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "top_selling_items_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["inventoryDecrementPolicy"];
        readonly entityRefs: readonly ["CardapioEntity", "PedidoEntity"];
    };
    export default useCase;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/atualizarCategoriaCardapio-commands.defs" {
    export const atualizarCategoriaCardapioCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "atualizarCategoriaCardapio";
        readonly moduleName: "cafeFlow";
        readonly status: "incomplete";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 61;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "atualizarCategoriaCardapio";
                readonly commands: readonly [{
                    readonly commandId: "atualizarCategoriaCardapio";
                    readonly input: readonly [{
                        readonly name: "categoryId";
                        readonly type: "string";
                        readonly required: true;
                    }, {
                        readonly name: "categoria";
                        readonly type: "CardapioEntity";
                        readonly required: true;
                    }];
                    readonly output: readonly [{
                        readonly name: "categoriaAtualizada";
                        readonly type: "CardapioEntity";
                    }];
                }];
            };
            readonly pendingQuestions: readonly ["Quais campos de CardapioEntity podem ser atualizados na categoria (ex.: nome, descrição, status/ativo, ordem)?", "O identificador da categoria é um campo do próprio CardapioEntity ou separado (categoryId)? Qual é o nome oficial desse campo?", "Há validações obrigatórias (ex.: nome único) que impactem a assinatura do comando?"];
        };
    };
    export default atualizarCategoriaCardapioCommands;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/atualizarCategoriaCardapio.defs" {
    export const useCase: {
        readonly usecaseId: "atualizarCategoriaCardapio";
        readonly title: "Atualizar categoria do cardápio";
        readonly purpose: "Atualiza os dados de uma categoria existente.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["CardapioEntity"];
        readonly outputEntities: readonly ["CardapioEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "menu_category";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "menu_category";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["CardapioEntity"];
    };
    export default useCase;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/atualizarIngredienteItemCardapio-commands.defs" {
    export const atualizarIngredienteItemCardapioCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "atualizarIngredienteItemCardapio";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 59;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "atualizarIngredienteItemCardapio";
                readonly commands: readonly [{
                    readonly commandId: "atualizarIngredienteItemCardapio";
                    readonly input: readonly [{
                        readonly name: "itemCardapioId";
                        readonly type: "string";
                        readonly required: true;
                    }, {
                        readonly name: "ingredienteId";
                        readonly type: "string";
                        readonly required: true;
                    }, {
                        readonly name: "quantidade";
                        readonly type: "number";
                        readonly required: false;
                    }, {
                        readonly name: "itemEstoqueId";
                        readonly type: "string";
                        readonly required: false;
                    }];
                    readonly output: readonly [{
                        readonly name: "cardapio";
                        readonly type: "CardapioEntity";
                    }];
                }];
            };
        };
    };
    export default atualizarIngredienteItemCardapioCommands;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/atualizarIngredienteItemCardapio.defs" {
    export const useCase: {
        readonly usecaseId: "atualizarIngredienteItemCardapio";
        readonly title: "Atualizar ingrediente do item do cardápio";
        readonly purpose: "Atualiza a quantidade ou item de estoque vinculado.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["CardapioEntity"];
        readonly outputEntities: readonly ["CardapioEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "menu_item_ingredient";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "menu_item_ingredient";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["CardapioEntity"];
    };
    export default useCase;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/atualizarItemEstoque-commands.defs" {
    export const atualizarItemEstoqueCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "atualizarItemEstoque";
        readonly moduleName: "cafeFlow";
        readonly status: "incomplete";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 61;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "atualizarItemEstoque";
                readonly commands: readonly [{
                    readonly commandId: "atualizarItemEstoque";
                    readonly input: readonly [{
                        readonly name: "estoqueItemId";
                        readonly type: "string";
                        readonly required: true;
                    }, {
                        readonly name: "quantidade";
                        readonly type: "number";
                        readonly required: false;
                    }, {
                        readonly name: "dadosItem";
                        readonly type: "string";
                        readonly required: false;
                    }];
                    readonly output: readonly [{
                        readonly name: "estoqueItem";
                        readonly type: "EstoqueEntity";
                    }];
                }];
            };
            readonly pendingQuestions: readonly ["Quais campos específicos de EstoqueEntity podem ser atualizados além da quantidade (ex.: nome, categoria, localização, custo)?", "Existe um identificador oficial do item de estoque que deve ser usado (ex.: itemId, sku)?", "A atualização deve permitir campos parciais?", "O retorno deve incluir apenas o item atualizado ou algum indicador extra (ex.: métricas de baixo estoque)?"];
        };
    };
    export default atualizarItemEstoqueCommands;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/atualizarItemEstoque.defs" {
    export const useCase: {
        readonly usecaseId: "atualizarItemEstoque";
        readonly title: "Atualizar item de estoque";
        readonly purpose: "Atualiza dados e quantidade de um item de estoque.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["EstoqueEntity"];
        readonly outputEntities: readonly ["EstoqueEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "inventory_item";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "inventory_item";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "low_stock_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["inventoryLowStockAlert"];
        readonly entityRefs: readonly ["EstoqueEntity"];
    };
    export default useCase;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/atualizarStatusPedido-commands.defs" {
    export const atualizarStatusPedidoCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "atualizarStatusPedido";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 60;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "atualizarStatusPedido";
                readonly commands: readonly [{
                    readonly commandId: "atualizarStatusPedido";
                    readonly input: readonly [{
                        readonly name: "pedidoId";
                        readonly type: "string";
                        readonly required: true;
                    }, {
                        readonly name: "novoStatus";
                        readonly type: "string";
                        readonly required: true;
                    }];
                    readonly output: readonly [{
                        readonly name: "pedidoId";
                        readonly type: "string";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                    }];
                }];
            };
        };
    };
    export default atualizarStatusPedidoCommands;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/atualizarStatusPedido.defs" {
    export const useCase: {
        readonly usecaseId: "atualizarStatusPedido";
        readonly title: "Atualizar status do pedido";
        readonly purpose: "Atualiza o status do pedido na cozinha (preparando, pronto, entregue).";
        readonly actor: "cozinha";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["PedidoEntity"];
        readonly outputEntities: readonly ["PedidoEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "daily_sales_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["orderStatusLifecycle", "kitchenStatusUpdates"];
        readonly entityRefs: readonly ["PedidoEntity", "TurnoEntity"];
    };
    export default useCase;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/confirmarAjusteEstoque-commands.defs" {
    export const confirmarAjusteEstoqueCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "confirmarAjusteEstoque";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 62;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "confirmarAjusteEstoque";
                readonly commands: readonly [{
                    readonly commandId: "confirmarAjusteEstoque";
                    readonly input: readonly [{
                        readonly name: "ajusteEstoqueId";
                        readonly type: "string";
                        readonly required: true;
                    }];
                    readonly output: readonly [{
                        readonly name: "estoqueId";
                        readonly type: "string";
                    }];
                }];
            };
        };
    };
    export default confirmarAjusteEstoqueCommands;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/confirmarAjusteEstoque.defs" {
    export const useCase: {
        readonly usecaseId: "confirmarAjusteEstoque";
        readonly title: "Confirmar ajuste de estoque";
        readonly purpose: "Confirma o ajuste e aplica a movimentação no item de estoque.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["EstoqueEntity"];
        readonly outputEntities: readonly ["EstoqueEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "inventory_adjustment";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_item";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "inventory_adjustment";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_item";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "low_stock_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["inventoryLowStockAlert"];
        readonly entityRefs: readonly ["EstoqueEntity"];
    };
    export default useCase;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/consultarDashboard-commands.defs" {
    export const consultarDashboardCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "consultarDashboard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 59;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "consultarDashboard";
                readonly commands: readonly [{
                    readonly commandId: "consultarDashboard";
                    readonly input: readonly [];
                    readonly output: readonly [{
                        readonly name: "pedidos";
                        readonly type: "PedidoEntity[]";
                    }, {
                        readonly name: "turnos";
                        readonly type: "TurnoEntity[]";
                    }, {
                        readonly name: "estoqueItens";
                        readonly type: "EstoqueEntity[]";
                    }, {
                        readonly name: "metricasVendasDiarias";
                        readonly type: "DailySalesMetric[]";
                    }, {
                        readonly name: "itensMaisVendidos";
                        readonly type: "TopSellingItemMetric[]";
                    }, {
                        readonly name: "alertasBaixoEstoque";
                        readonly type: "LowStockMetric[]";
                    }];
                }];
            };
        };
    };
    export default consultarDashboardCommands;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/consultarDashboard.defs" {
    export const useCase: {
        readonly usecaseId: "consultarDashboard";
        readonly title: "Consultar dashboard";
        readonly purpose: "Consolida métricas e dados operacionais para o dashboard do gerente.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly ["PedidoEntity", "EstoqueEntity", "TurnoEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "daily_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "top_selling_items_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "low_stock_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_item";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["EstoqueEntity", "PedidoEntity", "TurnoEntity"];
    };
    export default useCase;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/criarAjusteEstoque-commands.defs" {
    export const criarAjusteEstoqueCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "criarAjusteEstoque";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 60;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "criarAjusteEstoque";
                readonly commands: readonly [{
                    readonly commandId: "criarAjusteEstoque";
                    readonly input: readonly [{
                        readonly name: "inventoryItemId";
                        readonly type: "string";
                        readonly required: true;
                    }, {
                        readonly name: "ajusteTipo";
                        readonly type: "string";
                        readonly required: true;
                    }, {
                        readonly name: "quantidade";
                        readonly type: "number";
                        readonly required: true;
                    }];
                    readonly output: readonly [{
                        readonly name: "inventoryItemId";
                        readonly type: "string";
                    }, {
                        readonly name: "quantidadeAtual";
                        readonly type: "number";
                    }];
                }];
            };
        };
    };
    export default criarAjusteEstoqueCommands;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/criarAjusteEstoque.defs" {
    export const useCase: {
        readonly usecaseId: "criarAjusteEstoque";
        readonly title: "Criar ajuste de estoque";
        readonly purpose: "Registra um ajuste de entrada ou saída no estoque.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["EstoqueEntity"];
        readonly outputEntities: readonly ["EstoqueEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "inventory_item";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "inventory_adjustment";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "low_stock_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["EstoqueEntity"];
    };
    export default useCase;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/criarCategoriaCardapio-commands.defs" {
    export const criarCategoriaCardapioCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "criarCategoriaCardapio";
        readonly moduleName: "cafeFlow";
        readonly status: "incomplete";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 60;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "criarCategoriaCardapio";
                readonly commands: readonly [{
                    readonly commandId: "criarCategoriaCardapio";
                    readonly input: readonly [{
                        readonly name: "nome";
                        readonly type: "string";
                        readonly required: true;
                    }];
                    readonly output: readonly [{
                        readonly name: "categoriaId";
                        readonly type: "string";
                    }];
                }];
            };
            readonly pendingQuestions: readonly ["Além do nome, quais outros campos são obrigatórios para criar uma categoria (ex.: descrição, ordem de exibição, cardapioId)?", "O comando deve retornar apenas o identificador da categoria ou a entidade completa? Quais campos no retorno?"];
        };
    };
    export default criarCategoriaCardapioCommands;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/criarCategoriaCardapio.defs" {
    export const useCase: {
        readonly usecaseId: "criarCategoriaCardapio";
        readonly title: "Criar categoria do cardápio";
        readonly purpose: "Cria uma nova categoria no cardápio.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["CardapioEntity"];
        readonly outputEntities: readonly ["CardapioEntity"];
        readonly readsTables: readonly [];
        readonly writesTables: readonly [{
            readonly tableName: "menu_category";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["CardapioEntity"];
    };
    export default useCase;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/criarIngredienteItemCardapio-commands.defs" {
    export const criarIngredienteItemCardapioCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "criarIngredienteItemCardapio";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 58;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "criarIngredienteItemCardapio";
                readonly commands: readonly [{
                    readonly commandId: "criarIngredienteItemCardapio";
                    readonly input: readonly [{
                        readonly name: "menuItemId";
                        readonly type: "string";
                        readonly required: true;
                    }, {
                        readonly name: "inventoryItemId";
                        readonly type: "string";
                        readonly required: true;
                    }];
                    readonly output: readonly [{
                        readonly name: "cardapioId";
                        readonly type: "string";
                    }];
                }];
            };
        };
    };
    export default criarIngredienteItemCardapioCommands;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/criarIngredienteItemCardapio.defs" {
    export const useCase: {
        readonly usecaseId: "criarIngredienteItemCardapio";
        readonly title: "Criar ingrediente do item do cardápio";
        readonly purpose: "Vincula um item de estoque como ingrediente de um item do cardápio MDM.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["CardapioEntity"];
        readonly outputEntities: readonly ["CardapioEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "menu_item";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "inventory_item";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "menu_item_ingredient";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["CardapioEntity", "EstoqueEntity"];
    };
    export default useCase;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/criarItemEstoque-commands.defs" {
    export const criarItemEstoqueCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "criarItemEstoque";
        readonly moduleName: "cafeFlow";
        readonly status: "incomplete";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 62;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "criarItemEstoque";
                readonly commands: readonly [{
                    readonly commandId: "criarItemEstoque";
                    readonly input: readonly [{
                        readonly name: "estoque";
                        readonly type: "EstoqueEntity";
                        readonly required: true;
                    }];
                    readonly output: readonly [{
                        readonly name: "estoque";
                        readonly type: "EstoqueEntity";
                    }];
                }];
            };
            readonly pendingQuestions: readonly ["Quais campos compõem a EstoqueEntity para o cadastro do item?", "Existe algum identificador gerado que precise ser retornado além da EstoqueEntity completa?"];
        };
    };
    export default criarItemEstoqueCommands;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/criarItemEstoque.defs" {
    export const useCase: {
        readonly usecaseId: "criarItemEstoque";
        readonly title: "Criar item de estoque";
        readonly purpose: "Cadastra um novo item no estoque.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["EstoqueEntity"];
        readonly outputEntities: readonly ["EstoqueEntity"];
        readonly readsTables: readonly [];
        readonly writesTables: readonly [{
            readonly tableName: "inventory_item";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "low_stock_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["inventoryLowStockAlert"];
        readonly entityRefs: readonly ["EstoqueEntity"];
    };
    export default useCase;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/criarPedido-commands.defs" {
    export const criarPedidoCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "criarPedido";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 58;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "criarPedido";
                readonly commands: readonly [{
                    readonly commandId: "criarPedido";
                    readonly input: readonly [{
                        readonly name: "pedido";
                        readonly type: "PedidoEntity";
                        readonly required: true;
                    }];
                    readonly output: readonly [{
                        readonly name: "pedido";
                        readonly type: "PedidoEntity";
                    }];
                }];
            };
        };
    };
    export default criarPedidoCommands;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/criarPedido.defs" {
    export const useCase: {
        readonly usecaseId: "criarPedido";
        readonly title: "Criar pedido";
        readonly purpose: "Registra um novo pedido no POS vinculado ao turno aberto.";
        readonly actor: "atendenteCaixa";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["PedidoEntity"];
        readonly outputEntities: readonly ["PedidoEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "daily_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "top_selling_items_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["orderStatusLifecycle", "shiftMustBeOpenForOrders", "inventoryDecrementPolicy"];
        readonly entityRefs: readonly ["PedidoEntity", "TurnoEntity"];
    };
    export default useCase;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/excluirCategoriaCardapio-commands.defs" {
    export const excluirCategoriaCardapioCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "excluirCategoriaCardapio";
        readonly moduleName: "cafeFlow";
        readonly status: "incomplete";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 59;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "excluirCategoriaCardapio";
                readonly commands: readonly [{
                    readonly commandId: "excluirCategoriaCardapio";
                    readonly input: readonly [{
                        readonly name: "cardapioId";
                        readonly type: "string";
                        readonly required: true;
                    }, {
                        readonly name: "categoriaId";
                        readonly type: "string";
                        readonly required: true;
                    }];
                    readonly output: readonly [];
                }];
            };
            readonly pendingQuestions: readonly ["Qual é o identificador obrigatório para excluir a categoria: apenas categoriaId ou também cardapioId?", "Existe algum retorno esperado (por exemplo, categoria removida ou confirmação)?"];
        };
    };
    export default excluirCategoriaCardapioCommands;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/excluirCategoriaCardapio.defs" {
    export const useCase: {
        readonly usecaseId: "excluirCategoriaCardapio";
        readonly title: "Excluir categoria do cardápio";
        readonly purpose: "Remove uma categoria do cardápio.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["CardapioEntity"];
        readonly outputEntities: readonly [];
        readonly readsTables: readonly [{
            readonly tableName: "menu_category";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "menu_category";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["CardapioEntity"];
    };
    export default useCase;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/excluirIngredienteItemCardapio-commands.defs" {
    export const excluirIngredienteItemCardapioCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "excluirIngredienteItemCardapio";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 62;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "excluirIngredienteItemCardapio";
                readonly commands: readonly [{
                    readonly commandId: "excluirIngredienteItemCardapio";
                    readonly input: readonly [{
                        readonly name: "itemCardapioId";
                        readonly type: "string";
                        readonly required: true;
                    }, {
                        readonly name: "ingredienteId";
                        readonly type: "string";
                        readonly required: true;
                    }];
                    readonly output: readonly [];
                }];
            };
        };
    };
    export default excluirIngredienteItemCardapioCommands;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/excluirIngredienteItemCardapio.defs" {
    export const useCase: {
        readonly usecaseId: "excluirIngredienteItemCardapio";
        readonly title: "Excluir ingrediente do item do cardápio";
        readonly purpose: "Remove o vínculo entre item do cardápio e ingrediente.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["CardapioEntity"];
        readonly outputEntities: readonly [];
        readonly readsTables: readonly [{
            readonly tableName: "menu_item_ingredient";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "menu_item_ingredient";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["CardapioEntity"];
    };
    export default useCase;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/excluirItemEstoque-commands.defs" {
    export const excluirItemEstoqueCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "excluirItemEstoque";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 59;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "excluirItemEstoque";
                readonly commands: readonly [{
                    readonly commandId: "excluirItemEstoque";
                    readonly input: readonly [{
                        readonly name: "inventoryItemId";
                        readonly type: "string";
                        readonly required: true;
                    }];
                    readonly output: readonly [];
                }];
            };
        };
    };
    export default excluirItemEstoqueCommands;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/excluirItemEstoque.defs" {
    export const useCase: {
        readonly usecaseId: "excluirItemEstoque";
        readonly title: "Excluir item de estoque";
        readonly purpose: "Remove um item de estoque.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["EstoqueEntity"];
        readonly outputEntities: readonly [];
        readonly readsTables: readonly [{
            readonly tableName: "inventory_item";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "inventory_item";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "low_stock_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["EstoqueEntity"];
    };
    export default useCase;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/fecharTurno-commands.defs" {
    export const fecharTurnoCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "fecharTurno";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 61;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "fecharTurno";
                readonly commands: readonly [{
                    readonly commandId: "fecharTurno";
                    readonly input: readonly [{
                        readonly name: "turnoId";
                        readonly type: "string";
                        readonly required: true;
                    }];
                    readonly output: readonly [{
                        readonly name: "turno";
                        readonly type: "TurnoEntity";
                    }];
                }];
            };
        };
    };
    export default fecharTurnoCommands;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/fecharTurno.defs" {
    export const useCase: {
        readonly usecaseId: "fecharTurno";
        readonly title: "Fechar turno diário";
        readonly purpose: "Consolida o turno, gera relatório e atualiza métricas de vendas.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["TurnoEntity"];
        readonly outputEntities: readonly ["TurnoEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "daily_sales_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["shiftCloseRequiresOrders", "shiftMustBeOpenForOrders"];
        readonly entityRefs: readonly ["PedidoEntity", "TurnoEntity"];
    };
    export default useCase;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarAjustesEstoque-commands.defs" {
    export const listarAjustesEstoqueCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "listarAjustesEstoque";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 58;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "listarAjustesEstoque";
                readonly commands: readonly [{
                    readonly commandId: "listarAjustesEstoque";
                    readonly input: readonly [];
                    readonly output: readonly [{
                        readonly name: "ajustesEstoque";
                        readonly type: "EstoqueEntity[]";
                    }];
                }];
            };
        };
    };
    export default listarAjustesEstoqueCommands;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarAjustesEstoque.defs" {
    export const useCase: {
        readonly usecaseId: "listarAjustesEstoque";
        readonly title: "Listar ajustes de estoque";
        readonly purpose: "Lista histórico de ajustes de estoque.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly ["EstoqueEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "inventory_adjustment";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_item";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["EstoqueEntity"];
    };
    export default useCase;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarCategoriasCardapio-commands.defs" {
    export const listarCategoriasCardapioCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "listarCategoriasCardapio";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 62;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "listarCategoriasCardapio";
                readonly commands: readonly [{
                    readonly commandId: "listarCategoriasCardapio";
                    readonly input: readonly [];
                    readonly output: readonly [{
                        readonly name: "categorias";
                        readonly type: "CardapioEntity[]";
                    }];
                }];
            };
        };
    };
    export default listarCategoriasCardapioCommands;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarCategoriasCardapio.defs" {
    export const useCase: {
        readonly usecaseId: "listarCategoriasCardapio";
        readonly title: "Listar categorias do cardápio";
        readonly purpose: "Lista todas as categorias do cardápio.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly ["CardapioEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "menu_category";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["CardapioEntity"];
    };
    export default useCase;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarIngredientesItemCardapio-commands.defs" {
    export const listarIngredientesItemCardapioCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "listarIngredientesItemCardapio";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 60;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "listarIngredientesItemCardapio";
                readonly commands: readonly [{
                    readonly commandId: "listarIngredientesItemCardapio";
                    readonly input: readonly [{
                        readonly name: "menuItemId";
                        readonly type: "string";
                        readonly required: true;
                    }];
                    readonly output: readonly [{
                        readonly name: "ingredientes";
                        readonly type: "CardapioIngrediente[]";
                    }];
                }];
            };
        };
    };
    export default listarIngredientesItemCardapioCommands;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarIngredientesItemCardapio.defs" {
    export const useCase: {
        readonly usecaseId: "listarIngredientesItemCardapio";
        readonly title: "Listar ingredientes do item do cardápio";
        readonly purpose: "Lista ingredientes com referências aos itens MDM e estoque.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly ["CardapioEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "menu_item_ingredient";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "menu_item";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "inventory_item";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["CardapioEntity", "EstoqueEntity"];
    };
    export default useCase;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarItensCardapioMdm-commands.defs" {
    export const listarItensCardapioMdmCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "listarItensCardapioMdm";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 61;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "listarItensCardapioMdm";
                readonly commands: readonly [{
                    readonly commandId: "listarItensCardapioMdm";
                    readonly input: readonly [];
                    readonly output: readonly [{
                        readonly name: "itensCardapio";
                        readonly type: "CardapioEntity[]";
                    }];
                }];
            };
        };
    };
    export default listarItensCardapioMdmCommands;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarItensCardapioMdm.defs" {
    export const useCase: {
        readonly usecaseId: "listarItensCardapioMdm";
        readonly title: "Listar itens do cardápio MDM";
        readonly purpose: "Consulta os itens do cardápio mantidos no MDM.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly ["CardapioEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "menu_item";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["CardapioEntity"];
    };
    export default useCase;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarItensEstoque-commands.defs" {
    export const listarItensEstoqueCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "listarItensEstoque";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 58;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "listarItensEstoque";
                readonly commands: readonly [{
                    readonly commandId: "listarItensEstoque";
                    readonly input: readonly [];
                    readonly output: readonly [{
                        readonly name: "itensEstoque";
                        readonly type: "EstoqueEntity[]";
                    }];
                }];
            };
        };
    };
    export default listarItensEstoqueCommands;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarItensEstoque.defs" {
    export const useCase: {
        readonly usecaseId: "listarItensEstoque";
        readonly title: "Listar itens de estoque";
        readonly purpose: "Lista todos os itens de estoque.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly ["EstoqueEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "inventory_item";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["EstoqueEntity"];
    };
    export default useCase;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarPedidos-commands.defs" {
    export const listarPedidosCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "listarPedidos";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 61;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "listarPedidos";
                readonly commands: readonly [{
                    readonly commandId: "listarPedidos";
                    readonly input: readonly [];
                    readonly output: readonly [{
                        readonly name: "pedidos";
                        readonly type: "PedidoEntity[]";
                    }];
                }];
            };
        };
    };
    export default listarPedidosCommands;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarPedidos.defs" {
    export const useCase: {
        readonly usecaseId: "listarPedidos";
        readonly title: "Listar pedidos";
        readonly purpose: "Lista pedidos para o atendimento e acompanhamento.";
        readonly actor: "atendenteCaixa";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly ["PedidoEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["PedidoEntity"];
    };
    export default useCase;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarPedidosCozinha-commands.defs" {
    export const listarPedidosCozinhaCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "listarPedidosCozinha";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 62;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "listarPedidosCozinha";
                readonly commands: readonly [{
                    readonly commandId: "listarPedidosCozinha";
                    readonly input: readonly [];
                    readonly output: readonly [{
                        readonly name: "pedidos";
                        readonly type: "PedidoEntity[]";
                    }];
                }];
            };
        };
    };
    export default listarPedidosCozinhaCommands;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarPedidosCozinha.defs" {
    export const useCase: {
        readonly usecaseId: "listarPedidosCozinha";
        readonly title: "Listar pedidos da cozinha";
        readonly purpose: "Lista pedidos pendentes e em preparação para a cozinha.";
        readonly actor: "cozinha";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly ["PedidoEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["PedidoEntity"];
    };
    export default useCase;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarSolicitacoesIa-commands.defs" {
    export const listarSolicitacoesIaCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "listarSolicitacoesIa";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 60;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "listarSolicitacoesIa";
                readonly commands: readonly [{
                    readonly commandId: "listarSolicitacoesIa";
                    readonly input: readonly [];
                    readonly output: readonly [{
                        readonly name: "solicitacoes";
                        readonly type: "AiInsightEntity[]";
                    }];
                }];
            };
        };
    };
    export default listarSolicitacoesIaCommands;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarSolicitacoesIa.defs" {
    export const useCase: {
        readonly usecaseId: "listarSolicitacoesIa";
        readonly title: "Listar solicitações IA";
        readonly purpose: "Lista histórico de solicitações de insights.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly ["AiInsightEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "ai_insight_request";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["AiInsightEntity"];
    };
    export default useCase;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarTurnos-commands.defs" {
    export const listarTurnosCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "listarTurnos";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 60;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "listarTurnos";
                readonly commands: readonly [{
                    readonly commandId: "listarTurnos";
                    readonly input: readonly [];
                    readonly output: readonly [{
                        readonly name: "turnos";
                        readonly type: "TurnoEntity[]";
                    }];
                }];
            };
        };
    };
    export default listarTurnosCommands;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarTurnos.defs" {
    export const useCase: {
        readonly usecaseId: "listarTurnos";
        readonly title: "Listar turnos";
        readonly purpose: "Lista histórico de turnos diários.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly ["TurnoEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["TurnoEntity"];
    };
    export default useCase;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/obterPedido-commands.defs" {
    export const obterPedidoCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "obterPedido";
        readonly moduleName: "cafeFlow";
        readonly status: "incomplete";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 58;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "obterPedido";
                readonly commands: readonly [{
                    readonly commandId: "obterPedido";
                    readonly input: readonly [{
                        readonly name: "pedidoId";
                        readonly type: "string";
                        readonly required: true;
                    }];
                    readonly output: readonly [{
                        readonly name: "pedido";
                        readonly type: "PedidoEntity";
                    }];
                }];
            };
            readonly pendingQuestions: readonly ["Qual é o identificador do pedido que deve ser usado como entrada (ex.: pedidoId)?"];
        };
    };
    export default obterPedidoCommands;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/obterPedido.defs" {
    export const useCase: {
        readonly usecaseId: "obterPedido";
        readonly title: "Obter pedido";
        readonly purpose: "Retorna os detalhes de um pedido específico.";
        readonly actor: "atendenteCaixa";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["PedidoEntity"];
        readonly outputEntities: readonly ["PedidoEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["PedidoEntity"];
    };
    export default useCase;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/obterSolicitacaoIa-commands.defs" {
    export const obterSolicitacaoIaCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "obterSolicitacaoIa";
        readonly moduleName: "cafeFlow";
        readonly status: "incomplete";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 62;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "obterSolicitacaoIa";
                readonly commands: readonly [{
                    readonly commandId: "obterSolicitacaoIa";
                    readonly input: readonly [{
                        readonly name: "aiInsightId";
                        readonly type: "string";
                        readonly required: true;
                    }];
                    readonly output: readonly [{
                        readonly name: "aiInsight";
                        readonly type: "AiInsightEntity";
                    }];
                }];
            };
            readonly pendingQuestions: readonly ["Qual é o identificador usado para buscar a solicitação (por exemplo, aiInsightId ou outro campo)?"];
        };
    };
    export default obterSolicitacaoIaCommands;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/obterSolicitacaoIa.defs" {
    export const useCase: {
        readonly usecaseId: "obterSolicitacaoIa";
        readonly title: "Obter solicitação IA";
        readonly purpose: "Retorna detalhes de uma solicitação de insight.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["AiInsightEntity"];
        readonly outputEntities: readonly ["AiInsightEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "ai_insight_request";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["AiInsightEntity"];
    };
    export default useCase;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/obterTurno-commands.defs" {
    export const obterTurnoCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "obterTurno";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 58;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "obterTurno";
                readonly commands: readonly [{
                    readonly commandId: "obterTurno";
                    readonly input: readonly [{
                        readonly name: "turnoId";
                        readonly type: "string";
                        readonly required: true;
                    }];
                    readonly output: readonly [{
                        readonly name: "turno";
                        readonly type: "TurnoEntity";
                    }];
                }];
            };
        };
    };
    export default obterTurnoCommands;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/obterTurno.defs" {
    export const useCase: {
        readonly usecaseId: "obterTurno";
        readonly title: "Obter turno";
        readonly purpose: "Retorna detalhes de um turno específico.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["TurnoEntity"];
        readonly outputEntities: readonly ["TurnoEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["TurnoEntity"];
    };
    export default useCase;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/solicitarResumoIa-commands.defs" {
    export const solicitarResumoIaCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "solicitarResumoIa";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 61;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "solicitarResumoIa";
                readonly commands: readonly [{
                    readonly commandId: "solicitarResumoIa";
                    readonly input: readonly [];
                    readonly output: readonly [{
                        readonly name: "aiInsight";
                        readonly type: "AiInsightEntity";
                    }];
                }];
            };
        };
    };
    export default solicitarResumoIaCommands;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/solicitarResumoIa.defs" {
    export const useCase: {
        readonly usecaseId: "solicitarResumoIa";
        readonly title: "Solicitar resumo IA";
        readonly purpose: "Solicita insights baseados em métricas consolidadas ao assistente IA.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["AiInsightEntity"];
        readonly outputEntities: readonly ["AiInsightEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "daily_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "top_selling_items_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "low_stock_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "ai_insight_request";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["aiInsightsUseMetrics"];
        readonly entityRefs: readonly ["AiInsightEntity", "EstoqueEntity", "PedidoEntity", "TurnoEntity"];
    };
    export default useCase;
}
declare module "_102043_/l1/cafeFlow/layer_4_entities/AiInsightEntity.defs" {
    export const entity: {
        readonly entityId: "AiInsightEntity";
        readonly title: "Entidade de Insight IA";
        readonly purpose: "Gerencia solicitações de insights da IA baseadas em métricas consolidadas.";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "aiInsightRequestId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único da solicitação de insight IA.";
        }, {
            readonly fieldId: "insightType";
            readonly type: "string";
            readonly required: true;
            readonly description: "Tipo de insight solicitado.";
            readonly enum: readonly ["resumoVendas", "sugestaoPromocoes"];
        }, {
            readonly fieldId: "status";
            readonly type: "string";
            readonly required: true;
            readonly description: "Status atual da solicitação de insight.";
            readonly enum: readonly ["solicitado", "gerado", "falhou"];
        }, {
            readonly fieldId: "dailyShiftId";
            readonly type: "DailyShift";
            readonly required: false;
            readonly description: "Referência ao turno do dia relacionado à solicitação.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação da solicitação.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização da solicitação.";
        }];
        readonly statusEnum: readonly ["solicitado", "gerado", "falhou"];
        readonly lifecycleStates: readonly ["solicitado", "gerado", "falhou"];
        readonly sourceTables: readonly [{
            readonly tableName: "ai_insight_request";
            readonly ownership: "moduleOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "moduleTable";
            readonly tableId: "aiInsightRequest";
            readonly tableName: "ai_insight_request";
            readonly fileRef: "_102043_/l1/cafeFlow/layer_1_external/aiInsightRequest.defs.ts";
        }];
        readonly allowedOperations: readonly ["create", "read", "update", "list"];
        readonly rulesApplied: readonly ["aiInsightsUseMetrics"];
        readonly usecaseRefs: readonly ["solicitarResumoIa", "listarSolicitacoesIa", "obterSolicitacaoIa"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/AiInsightEntity.ts";
            readonly className: "AiInsightEntity";
            readonly contractName: "IAiInsightEntity";
        };
    };
    export default entity;
}
declare module "_102043_/l1/cafeFlow/layer_4_entities/CardapioEntity.defs" {
    export const entity: {
        readonly entityId: "CardapioEntity";
        readonly title: "Entidade de Cardápio";
        readonly purpose: "Agrega categorias do cardápio, ingredientes dos itens e referências aos itens MDM.";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "menuCategoryId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único da categoria";
        }, {
            readonly fieldId: "name";
            readonly type: "string";
            readonly required: true;
            readonly description: "Nome da categoria exibido no POS";
        }, {
            readonly fieldId: "description";
            readonly type: "text";
            readonly required: false;
            readonly description: "Descrição opcional da categoria";
        }, {
            readonly fieldId: "sortOrder";
            readonly type: "number";
            readonly required: false;
            readonly description: "Ordem de exibição no POS (menor valor aparece primeiro)";
        }, {
            readonly fieldId: "color";
            readonly type: "string";
            readonly required: false;
            readonly description: "Cor hexadecimal para identificação visual no POS";
        }, {
            readonly fieldId: "isActive";
            readonly type: "boolean";
            readonly required: true;
            readonly description: "Indica se a categoria está ativa e visível no cardápio";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do registro";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do registro";
        }];
        readonly sourceTables: readonly [{
            readonly tableName: "menu_category";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "menu_item_ingredient";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "menu_item";
            readonly ownership: "mdmOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "moduleTable";
            readonly tableId: "menuCategory";
            readonly tableName: "menu_category";
            readonly fileRef: "_102043_/l1/cafeFlow/layer_1_external/menuCategory.defs.ts";
        }, {
            readonly kind: "moduleTable";
            readonly tableId: "menuItemIngredient";
            readonly tableName: "menu_item_ingredient";
            readonly fileRef: "_102043_/l1/cafeFlow/layer_1_external/menuItemIngredient.defs.ts";
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "MenuItem";
            readonly domainId: "menuItem";
            readonly sourceOfTruth: "102034";
            readonly governanceRules: readonly ["Criação, edição e desativação de itens do cardápio são restritas ao ator gerente.", "Todo item do cardápio deve estar vinculado a uma categoria ativa do cardápio.", "Mudanças de preço e composição de ingredientes são auditadas pela infraestrutura MDM compartilhada."];
        }];
        readonly allowedOperations: readonly ["create", "read", "update", "delete", "list", "search"];
        readonly rulesApplied: readonly [];
        readonly usecaseRefs: readonly ["adicionarItemPedido", "criarCategoriaCardapio", "atualizarCategoriaCardapio", "excluirCategoriaCardapio", "listarCategoriasCardapio", "criarIngredienteItemCardapio", "atualizarIngredienteItemCardapio", "excluirIngredienteItemCardapio", "listarIngredientesItemCardapio", "listarItensCardapioMdm"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/CardapioEntity.ts";
            readonly className: "CardapioEntity";
            readonly contractName: "ICardapioEntity";
        };
    };
    export default entity;
}
declare module "_102043_/l1/cafeFlow/layer_4_entities/EstoqueEntity.defs" {
    export const entity: {
        readonly entityId: "EstoqueEntity";
        readonly title: "Entidade de Estoque";
        readonly purpose: "Agrega itens de estoque e ajustes, com alertas de estoque baixo e baixa automática.";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "inventoryItemId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do item de estoque.";
        }, {
            readonly fieldId: "name";
            readonly type: "string";
            readonly required: true;
            readonly description: "Nome do insumo ou item de estoque.";
        }, {
            readonly fieldId: "quantityAvailable";
            readonly type: "number";
            readonly required: true;
            readonly description: "Quantidade disponível em estoque.";
        }, {
            readonly fieldId: "minimumLevel";
            readonly type: "number";
            readonly required: true;
            readonly description: "Nível mínimo aceitável para o estoque.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do registro.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do registro.";
        }];
        readonly sourceTables: readonly [{
            readonly tableName: "inventory_item";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_adjustment";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "low_stock_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "moduleTable";
            readonly tableId: "inventoryItem";
            readonly tableName: "inventory_item";
            readonly fileRef: "_102043_/l1/cafeFlow/layer_1_external/inventoryItem.defs.ts";
        }, {
            readonly kind: "moduleTable";
            readonly tableId: "inventoryAdjustment";
            readonly tableName: "inventory_adjustment";
            readonly fileRef: "_102043_/l1/cafeFlow/layer_1_external/inventoryAdjustment.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "lowStockMetrics";
            readonly tableName: "low_stock_metrics";
            readonly fileRef: "_102043_/l1/cafeFlow/layer_1_external/lowStockMetrics.defs.ts";
        }];
        readonly allowedOperations: readonly ["create", "read", "update", "delete", "list", "search"];
        readonly rulesApplied: readonly ["inventoryLowStockAlert", "inventoryDecrementPolicy"];
        readonly usecaseRefs: readonly ["criarIngredienteItemCardapio", "listarIngredientesItemCardapio", "criarItemEstoque", "atualizarItemEstoque", "excluirItemEstoque", "listarItensEstoque", "criarAjusteEstoque", "confirmarAjusteEstoque", "listarAjustesEstoque", "solicitarResumoIa", "consultarDashboard"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/EstoqueEntity.ts";
            readonly className: "EstoqueEntity";
            readonly contractName: "IEstoqueEntity";
        };
    };
    export default entity;
}
declare module "_102043_/l1/cafeFlow/layer_4_entities/PedidoEntity.defs" {
    export const entity: {
        readonly entityId: "PedidoEntity";
        readonly title: "Entidade de Pedido";
        readonly purpose: "Agrega pedidos e itens do pedido, responsável pelo ciclo de vida do pedido e atualização das métricas de vendas.";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "orderId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do pedido.";
        }, {
            readonly fieldId: "dailyShiftId";
            readonly type: "DailyShift";
            readonly required: true;
            readonly description: "Referência ao turno diário ao qual o pedido pertence.";
        }, {
            readonly fieldId: "status";
            readonly type: "string";
            readonly required: true;
            readonly description: "Status atual do pedido.";
            readonly enum: readonly ["recebido", "preparando", "pronto", "entregue", "cancelado"];
        }, {
            readonly fieldId: "serviceType";
            readonly type: "string";
            readonly required: true;
            readonly description: "Tipo de atendimento do pedido (mesa ou takeout).";
            readonly enum: readonly ["mesa", "takeout"];
        }, {
            readonly fieldId: "tableNumber";
            readonly type: "string";
            readonly required: false;
            readonly description: "Número/identificador da mesa quando o atendimento é em mesa.";
        }, {
            readonly fieldId: "notes";
            readonly type: "text";
            readonly required: false;
            readonly description: "Observações gerais do pedido.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do pedido.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do pedido.";
        }];
        readonly statusEnum: readonly ["recebido", "preparando", "pronto", "entregue", "cancelado"];
        readonly lifecycleStates: readonly ["recebido", "preparando", "pronto", "entregue", "cancelado"];
        readonly sourceTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "daily_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "top_selling_items_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "moduleTable";
            readonly tableId: "order";
            readonly tableName: "order";
            readonly fileRef: "_102043_/l1/cafeFlow/layer_1_external/order.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "dailySalesMetrics";
            readonly tableName: "daily_sales_metrics";
            readonly fileRef: "_102043_/l1/cafeFlow/layer_1_external/dailySalesMetrics.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "topSellingItemsMetrics";
            readonly tableName: "top_selling_items_metrics";
            readonly fileRef: "_102043_/l1/cafeFlow/layer_1_external/topSellingItemsMetrics.defs.ts";
        }];
        readonly allowedOperations: readonly ["create", "read", "update", "list", "search"];
        readonly rulesApplied: readonly ["orderStatusLifecycle", "kitchenStatusUpdates", "shiftMustBeOpenForOrders", "inventoryDecrementPolicy"];
        readonly usecaseRefs: readonly ["criarPedido", "adicionarItemPedido", "atualizarStatusPedido", "listarPedidos", "listarPedidosCozinha", "obterPedido", "fecharTurno", "solicitarResumoIa", "consultarDashboard"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/PedidoEntity.ts";
            readonly className: "PedidoEntity";
            readonly contractName: "IPedidoEntity";
        };
    };
    export default entity;
}
declare module "_102043_/l1/cafeFlow/layer_4_entities/TurnoEntity.defs" {
    export const entity: {
        readonly entityId: "TurnoEntity";
        readonly title: "Entidade de Turno";
        readonly purpose: "Agrega turnos diários e relatórios de fechamento, consolidando métricas do dia.";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "dailyShiftId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do turno diário.";
        }, {
            readonly fieldId: "shiftDate";
            readonly type: "date";
            readonly required: true;
            readonly description: "Data do turno diário.";
        }, {
            readonly fieldId: "status";
            readonly type: "string";
            readonly required: true;
            readonly description: "Status do turno diário.";
            readonly enum: readonly ["aberto", "fechado"];
        }, {
            readonly fieldId: "openedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de abertura do turno.";
        }, {
            readonly fieldId: "closedAt";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Data e hora de fechamento do turno.";
        }, {
            readonly fieldId: "openingCashAmount";
            readonly type: "money";
            readonly required: false;
            readonly description: "Valor de caixa informado na abertura do turno.";
        }, {
            readonly fieldId: "closingCashAmount";
            readonly type: "money";
            readonly required: false;
            readonly description: "Valor de caixa informado no fechamento do turno.";
        }, {
            readonly fieldId: "totalSalesAmount";
            readonly type: "money";
            readonly required: false;
            readonly description: "Total de vendas consolidadas no turno.";
        }, {
            readonly fieldId: "totalOrders";
            readonly type: "number";
            readonly required: false;
            readonly description: "Quantidade total de pedidos no turno.";
        }, {
            readonly fieldId: "notes";
            readonly type: "text";
            readonly required: false;
            readonly description: "Observações gerais do turno.";
        }, {
            readonly fieldId: "shiftClosingReportId";
            readonly type: "ShiftClosingReport";
            readonly required: false;
            readonly description: "Referência ao relatório de fechamento do turno.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do registro.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do registro.";
        }];
        readonly statusEnum: readonly ["aberto", "fechado"];
        readonly sourceTables: readonly [{
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "daily_sales_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "moduleTable";
            readonly tableId: "dailyShift";
            readonly tableName: "daily_shift";
            readonly fileRef: "_102043_/l1/cafeFlow/layer_1_external/dailyShift.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "dailySalesMetrics";
            readonly tableName: "daily_sales_metrics";
            readonly fileRef: "_102043_/l1/cafeFlow/layer_1_external/dailySalesMetrics.defs.ts";
        }];
        readonly allowedOperations: readonly ["create", "read", "update", "list"];
        readonly rulesApplied: readonly ["shiftMustBeOpenForOrders", "shiftCloseRequiresOrders"];
        readonly usecaseRefs: readonly ["criarPedido", "atualizarStatusPedido", "abrirTurno", "fecharTurno", "listarTurnos", "obterTurno", "solicitarResumoIa", "consultarDashboard"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/TurnoEntity.ts";
            readonly className: "TurnoEntity";
            readonly contractName: "ITurnoEntity";
        };
    };
    export default entity;
}
declare module "_102043_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102043_/l2/cafeFlow/dashboard.defs" {
    export const dashboardPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "dashboard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 66;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "dashboard";
                readonly pageName: "Dashboard do gerente";
                readonly actor: "gerente";
                readonly purpose: "Acompanhar métricas de vendas, itens mais vendidos e alertas de estoque baixo.";
                readonly capabilities: readonly ["acompanharDashboard"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly ["dailySalesMetricsAutomation", "lowStockAlertAutomation"];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [{
                    readonly name: "periodStart";
                    readonly type: "date";
                    readonly required: false;
                    readonly sources: readonly ["queryParam", "defaultValue"];
                    readonly description: "Início do período para consolidação do dashboard.";
                }, {
                    readonly name: "periodEnd";
                    readonly type: "date";
                    readonly required: false;
                    readonly sources: readonly ["queryParam", "defaultValue"];
                    readonly description: "Fim do período para consolidação do dashboard.";
                }, {
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["queryParam", "userSelection"];
                    readonly description: "Identificador do turno diário quando o gerente filtra por turno.";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "gerenciamentoCardapioEstoque";
                    readonly trigger: "Ação em alerta de estoque baixo";
                    readonly description: "Abrir gestão de estoque para tratar o item com estoque baixo.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Filtros do dashboard";
                    readonly mode: "filter";
                    readonly organisms: readonly [{
                        readonly organismName: "Seletor de período e turno";
                        readonly purpose: "Permitir filtrar as métricas por dia e turno.";
                        readonly userActions: readonly ["selecionarPeriodo", "selecionarTurno", "aplicarFiltros"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Resumo de vendas";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "Cards de métricas de vendas";
                        readonly purpose: "Exibir receita total, quantidade de pedidos, itens vendidos e ticket médio.";
                        readonly userActions: readonly ["consultarDashboard"];
                        readonly requiredEntities: readonly ["PedidoEntity", "TurnoEntity"];
                        readonly readsFields: readonly ["dailySalesMetrics.totalRevenue", "dailySalesMetrics.orderCount", "dailySalesMetrics.itemsSold", "dailySalesMetrics.averageTicket"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Itens mais vendidos";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "Ranking de itens mais vendidos";
                        readonly purpose: "Listar itens mais vendidos e receita por item.";
                        readonly userActions: readonly ["consultarDashboard"];
                        readonly requiredEntities: readonly ["PedidoEntity"];
                        readonly readsFields: readonly ["topSellingItemsMetrics.menuItemId", "topSellingItemsMetrics.quantitySold", "topSellingItemsMetrics.itemRevenue", "topSellingItemsMetrics.orderCount"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Alertas de estoque baixo";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "Lista de alertas de estoque baixo";
                        readonly purpose: "Exibir itens com estoque abaixo do mínimo e permitir ação para gestão.";
                        readonly userActions: readonly ["consultarDashboard", "abrirGestaoEstoque"];
                        readonly requiredEntities: readonly ["EstoqueEntity"];
                        readonly readsFields: readonly ["lowStockMetrics.inventoryItemId", "lowStockMetrics.currentQuantity", "lowStockMetrics.thresholdQuantity", "lowStockMetrics.lowStockCount"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "consultarDashboard";
                readonly purpose: "Carregar métricas consolidadas para o dashboard do gerente.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "periodStart";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "periodEnd";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "totalRevenue";
                    readonly type: "number";
                }, {
                    readonly name: "orderCount";
                    readonly type: "number";
                }, {
                    readonly name: "itemsSold";
                    readonly type: "number";
                }, {
                    readonly name: "averageTicket";
                    readonly type: "number";
                }, {
                    readonly name: "topSellingItems";
                    readonly type: "TopSellingItem[]";
                }, {
                    readonly name: "lowStockAlerts";
                    readonly type: "LowStockAlert[]";
                }];
                readonly readsEntities: readonly ["PedidoEntity", "EstoqueEntity", "TurnoEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["daily_sales_metrics", "top_selling_items_metrics", "low_stock_metrics", "order", "daily_shift", "inventory_item"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["consultarDashboard"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default dashboardPagePlan;
}
declare module "_102043_/l2/cafeFlow/gerenciamentoCardapioEstoque.defs" {
    export const gerenciamentoCardapioEstoquePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "gerenciamentoCardapioEstoque";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 64;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "gerenciamentoCardapioEstoque";
                readonly pageName: "Gerenciamento de cardápio e estoque";
                readonly actor: "gerente";
                readonly purpose: "Manter cardápio, ingredientes e estoque básico com ajustes e alertas.";
                readonly capabilities: readonly ["gerenciarCardapio", "gerenciarEstoque"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["inventoryAdjustmentLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly ["lowStockAlertAutomation"];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["menuItem"];
                readonly pageInputs: readonly [{
                    readonly name: "abaAtiva";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["queryParam", "state"];
                    readonly description: "Aba inicial exibida: cardápio|estoque|ajustes";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "dashboard";
                    readonly trigger: "Ver alertas e métricas de estoque";
                    readonly description: "Abrir dashboard do gerente";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Categorias do cardápio";
                    readonly mode: "manage";
                    readonly organisms: readonly [{
                        readonly organismName: "ListaCategoriasCardapio";
                        readonly purpose: "Listar e filtrar categorias do cardápio para edição.";
                        readonly userActions: readonly ["filtrarCategorias", "selecionarCategoria"];
                        readonly requiredEntities: readonly ["MenuCategory"];
                        readonly readsFields: readonly ["MenuCategory.menuCategoryId", "MenuCategory.name", "MenuCategory.description", "MenuCategory.sortOrder", "MenuCategory.color", "MenuCategory.isActive", "MenuCategory.updatedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "EditorCategoriaCardapio";
                        readonly purpose: "Criar, atualizar e excluir categorias do cardápio.";
                        readonly userActions: readonly ["criarCategoria", "editarCategoria", "excluirCategoria"];
                        readonly requiredEntities: readonly ["MenuCategory"];
                        readonly readsFields: readonly ["MenuCategory.menuCategoryId", "MenuCategory.name", "MenuCategory.description", "MenuCategory.sortOrder", "MenuCategory.color", "MenuCategory.isActive"];
                        readonly writesFields: readonly ["MenuCategory.name", "MenuCategory.description", "MenuCategory.sortOrder", "MenuCategory.color", "MenuCategory.isActive"];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Ingredientes por item do cardápio";
                    readonly mode: "manage";
                    readonly organisms: readonly [{
                        readonly organismName: "SeletorItemCardapioMdm";
                        readonly purpose: "Selecionar item do cardápio MDM para gerenciar ingredientes.";
                        readonly userActions: readonly ["buscarItemCardapio", "selecionarItemCardapio"];
                        readonly requiredEntities: readonly ["MenuItem"];
                        readonly readsFields: readonly ["MenuItem.menuItemId", "MenuItem.name"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "ListaIngredientesItem";
                        readonly purpose: "Listar ingredientes vinculados ao item selecionado.";
                        readonly userActions: readonly ["listarIngredientes", "selecionarIngrediente"];
                        readonly requiredEntities: readonly ["MenuItemIngredient", "InventoryItem"];
                        readonly readsFields: readonly ["MenuItemIngredient.id", "MenuItemIngredient.menuItemId", "MenuItemIngredient.inventoryItemId", "MenuItemIngredient.quantity", "MenuItemIngredient.unit", "MenuItemIngredient.isOptional", "MenuItemIngredient.updatedAt", "InventoryItem.name"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "EditorIngredienteItem";
                        readonly purpose: "Vincular, atualizar ou remover ingredientes do item do cardápio.";
                        readonly userActions: readonly ["criarIngrediente", "editarIngrediente", "excluirIngrediente"];
                        readonly requiredEntities: readonly ["MenuItemIngredient", "InventoryItem"];
                        readonly readsFields: readonly ["MenuItemIngredient.id", "MenuItemIngredient.menuItemId", "MenuItemIngredient.inventoryItemId", "MenuItemIngredient.quantity", "MenuItemIngredient.unit", "MenuItemIngredient.isOptional"];
                        readonly writesFields: readonly ["MenuItemIngredient.inventoryItemId", "MenuItemIngredient.quantity", "MenuItemIngredient.unit", "MenuItemIngredient.isOptional"];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Itens de estoque";
                    readonly mode: "manage";
                    readonly organisms: readonly [{
                        readonly organismName: "ListaItensEstoque";
                        readonly purpose: "Listar itens de estoque e níveis atuais, com filtro de baixo estoque.";
                        readonly userActions: readonly ["filtrarEstoque", "selecionarItemEstoque"];
                        readonly requiredEntities: readonly ["InventoryItem"];
                        readonly readsFields: readonly ["InventoryItem.inventoryItemId", "InventoryItem.name", "InventoryItem.quantityAvailable", "InventoryItem.minimumLevel", "InventoryItem.updatedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["inventoryLowStockAlert"];
                    }, {
                        readonly organismName: "EditorItemEstoque";
                        readonly purpose: "Criar, atualizar ou excluir itens de estoque.";
                        readonly userActions: readonly ["criarItemEstoque", "editarItemEstoque", "excluirItemEstoque"];
                        readonly requiredEntities: readonly ["InventoryItem"];
                        readonly readsFields: readonly ["InventoryItem.inventoryItemId", "InventoryItem.name", "InventoryItem.quantityAvailable", "InventoryItem.minimumLevel"];
                        readonly writesFields: readonly ["InventoryItem.name", "InventoryItem.quantityAvailable", "InventoryItem.minimumLevel"];
                        readonly rulesApplied: readonly ["inventoryLowStockAlert"];
                    }];
                }, {
                    readonly sectionName: "Ajustes de estoque";
                    readonly mode: "manage";
                    readonly organisms: readonly [{
                        readonly organismName: "ListaAjustesEstoque";
                        readonly purpose: "Listar ajustes pendentes e históricos.";
                        readonly userActions: readonly ["filtrarAjustes", "selecionarAjuste"];
                        readonly requiredEntities: readonly ["InventoryAdjustment", "InventoryItem"];
                        readonly readsFields: readonly ["InventoryAdjustment.inventoryAdjustmentId", "InventoryAdjustment.inventoryItemId", "InventoryAdjustment.status", "InventoryAdjustment.createdAt", "InventoryItem.name"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "CriarAjusteEstoque";
                        readonly purpose: "Registrar ajuste de estoque com motivo.";
                        readonly userActions: readonly ["criarAjuste"];
                        readonly requiredEntities: readonly ["InventoryAdjustment", "InventoryItem"];
                        readonly readsFields: readonly ["InventoryItem.inventoryItemId", "InventoryItem.name", "InventoryItem.quantityAvailable"];
                        readonly writesFields: readonly ["InventoryAdjustment.inventoryItemId", "InventoryAdjustment.status"];
                        readonly rulesApplied: readonly ["inventoryDecrementPolicy"];
                    }, {
                        readonly organismName: "ConfirmarAjusteEstoque";
                        readonly purpose: "Confirmar ajuste pendente e aplicar movimentação no estoque.";
                        readonly userActions: readonly ["confirmarAjuste"];
                        readonly requiredEntities: readonly ["InventoryAdjustment", "InventoryItem"];
                        readonly readsFields: readonly ["InventoryAdjustment.inventoryAdjustmentId", "InventoryAdjustment.status", "InventoryAdjustment.inventoryItemId", "InventoryItem.name", "InventoryItem.quantityAvailable"];
                        readonly writesFields: readonly ["InventoryAdjustment.status", "InventoryItem.quantityAvailable"];
                        readonly rulesApplied: readonly ["inventoryLowStockAlert", "inventoryDecrementPolicy"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listarCategoriasCardapio";
                readonly purpose: "Carregar categorias do cardápio";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "textoBusca";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "apenasAtivas";
                    readonly type: "boolean";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "menuCategoryId";
                    readonly type: "uuid";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                }, {
                    readonly name: "sortOrder";
                    readonly type: "number";
                }, {
                    readonly name: "color";
                    readonly type: "string";
                }, {
                    readonly name: "isActive";
                    readonly type: "boolean";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["MenuCategory"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["menu_category"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarCategoriasCardapio"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "criarCategoriaCardapio";
                readonly purpose: "Adicionar nova categoria do cardápio";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "sortOrder";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "color";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "isActive";
                    readonly type: "boolean";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "menuCategoryId";
                    readonly type: "uuid";
                }];
                readonly readsEntities: readonly [];
                readonly writesEntities: readonly ["MenuCategory"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["menu_category"];
                readonly usecaseRefs: readonly ["criarCategoriaCardapio"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "atualizarCategoriaCardapio";
                readonly purpose: "Editar categoria do cardápio";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "menuCategoryId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "sortOrder";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "color";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "isActive";
                    readonly type: "boolean";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "menuCategoryId";
                    readonly type: "uuid";
                }];
                readonly readsEntities: readonly ["MenuCategory"];
                readonly writesEntities: readonly ["MenuCategory"];
                readonly readsTables: readonly ["menu_category"];
                readonly writesTables: readonly ["menu_category"];
                readonly usecaseRefs: readonly ["atualizarCategoriaCardapio"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "excluirCategoriaCardapio";
                readonly purpose: "Remover categoria do cardápio";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "menuCategoryId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "excluido";
                    readonly type: "boolean";
                }];
                readonly readsEntities: readonly ["MenuCategory"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["menu_category"];
                readonly writesTables: readonly ["menu_category"];
                readonly usecaseRefs: readonly ["excluirCategoriaCardapio"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "listarItensCardapioMdm";
                readonly purpose: "Listar itens do cardápio do MDM para seleção";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "textoBusca";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "categoriaId";
                    readonly type: "uuid";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "uuid";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["MenuItem"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarItensCardapioMdm"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "listarIngredientesItemCardapio";
                readonly purpose: "Listar ingredientes vinculados ao item do cardápio";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "menuItemIngredientId";
                    readonly type: "uuid";
                }, {
                    readonly name: "menuItemId";
                    readonly type: "uuid";
                }, {
                    readonly name: "inventoryItemId";
                    readonly type: "uuid";
                }, {
                    readonly name: "inventoryItemName";
                    readonly type: "string";
                }, {
                    readonly name: "quantity";
                    readonly type: "number";
                }, {
                    readonly name: "unit";
                    readonly type: "string";
                }, {
                    readonly name: "isOptional";
                    readonly type: "boolean";
                }];
                readonly readsEntities: readonly ["MenuItemIngredient", "InventoryItem"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["menu_item_ingredient", "inventory_item"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarIngredientesItemCardapio"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "criarIngredienteItemCardapio";
                readonly purpose: "Vincular ingrediente ao item do cardápio";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "inventoryItemId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "quantity";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "unit";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "isOptional";
                    readonly type: "boolean";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "menuItemIngredientId";
                    readonly type: "uuid";
                }];
                readonly readsEntities: readonly ["InventoryItem"];
                readonly writesEntities: readonly ["MenuItemIngredient"];
                readonly readsTables: readonly ["inventory_item"];
                readonly writesTables: readonly ["menu_item_ingredient"];
                readonly usecaseRefs: readonly ["criarIngredienteItemCardapio"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "atualizarIngredienteItemCardapio";
                readonly purpose: "Atualizar quantidade ou item vinculado";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "menuItemIngredientId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "inventoryItemId";
                    readonly type: "uuid";
                    readonly required: false;
                }, {
                    readonly name: "quantity";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "unit";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "isOptional";
                    readonly type: "boolean";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "menuItemIngredientId";
                    readonly type: "uuid";
                }];
                readonly readsEntities: readonly ["MenuItemIngredient"];
                readonly writesEntities: readonly ["MenuItemIngredient"];
                readonly readsTables: readonly ["menu_item_ingredient"];
                readonly writesTables: readonly ["menu_item_ingredient"];
                readonly usecaseRefs: readonly ["atualizarIngredienteItemCardapio"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "excluirIngredienteItemCardapio";
                readonly purpose: "Remover ingrediente do item do cardápio";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "menuItemIngredientId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "excluido";
                    readonly type: "boolean";
                }];
                readonly readsEntities: readonly ["MenuItemIngredient"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["menu_item_ingredient"];
                readonly writesTables: readonly ["menu_item_ingredient"];
                readonly usecaseRefs: readonly ["excluirIngredienteItemCardapio"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "listarItensEstoque";
                readonly purpose: "Listar itens de estoque e níveis atuais";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "textoBusca";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "baixoEstoque";
                    readonly type: "boolean";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "inventoryItemId";
                    readonly type: "uuid";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                }, {
                    readonly name: "quantityAvailable";
                    readonly type: "number";
                }, {
                    readonly name: "minimumLevel";
                    readonly type: "number";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["InventoryItem"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["inventory_item"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarItensEstoque"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["inventoryLowStockAlert"];
            }, {
                readonly commandName: "criarItemEstoque";
                readonly purpose: "Cadastrar novo item de estoque";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "unidade";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "estoqueInicial";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "minimumLevel";
                    readonly type: "number";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "inventoryItemId";
                    readonly type: "uuid";
                }];
                readonly readsEntities: readonly [];
                readonly writesEntities: readonly ["InventoryItem"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["inventory_item", "low_stock_metrics"];
                readonly usecaseRefs: readonly ["criarItemEstoque"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["inventoryLowStockAlert"];
            }, {
                readonly commandName: "atualizarItemEstoque";
                readonly purpose: "Atualizar dados de item de estoque";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "inventoryItemId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "quantityAvailable";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "minimumLevel";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "inventoryItemId";
                    readonly type: "uuid";
                }];
                readonly readsEntities: readonly ["InventoryItem"];
                readonly writesEntities: readonly ["InventoryItem"];
                readonly readsTables: readonly ["inventory_item"];
                readonly writesTables: readonly ["inventory_item", "low_stock_metrics"];
                readonly usecaseRefs: readonly ["atualizarItemEstoque"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["inventoryLowStockAlert"];
            }, {
                readonly commandName: "excluirItemEstoque";
                readonly purpose: "Excluir item de estoque";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "inventoryItemId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "excluido";
                    readonly type: "boolean";
                }];
                readonly readsEntities: readonly ["InventoryItem"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["inventory_item"];
                readonly writesTables: readonly ["inventory_item", "low_stock_metrics"];
                readonly usecaseRefs: readonly ["excluirItemEstoque"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "listarAjustesEstoque";
                readonly purpose: "Listar ajustes de estoque pendentes e históricos";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "dataInicio";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "dataFim";
                    readonly type: "date";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "inventoryAdjustmentId";
                    readonly type: "uuid";
                }, {
                    readonly name: "inventoryItemId";
                    readonly type: "uuid";
                }, {
                    readonly name: "inventoryItemName";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "createdAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["InventoryAdjustment", "InventoryItem"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["inventory_adjustment", "inventory_item"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarAjustesEstoque"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "criarAjusteEstoque";
                readonly purpose: "Criar ajuste de estoque com motivo";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "inventoryItemId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "quantidade";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "motivo";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "inventoryAdjustmentId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["InventoryItem"];
                readonly writesEntities: readonly ["InventoryAdjustment"];
                readonly readsTables: readonly ["inventory_item"];
                readonly writesTables: readonly ["inventory_adjustment", "low_stock_metrics"];
                readonly usecaseRefs: readonly ["criarAjusteEstoque"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "confirmarAjusteEstoque";
                readonly purpose: "Confirmar ajuste pendente e aplicar estoque";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "inventoryAdjustmentId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "inventoryAdjustmentId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "inventoryItemId";
                    readonly type: "uuid";
                }, {
                    readonly name: "quantityAvailable";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["InventoryAdjustment", "InventoryItem"];
                readonly writesEntities: readonly ["InventoryAdjustment", "InventoryItem"];
                readonly readsTables: readonly ["inventory_adjustment", "inventory_item"];
                readonly writesTables: readonly ["inventory_adjustment", "inventory_item", "low_stock_metrics"];
                readonly usecaseRefs: readonly ["confirmarAjusteEstoque"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["inventoryLowStockAlert"];
            }];
        };
    };
    export default gerenciamentoCardapioEstoquePagePlan;
}
declare module "_102043_/l2/cafeFlow/journeys.defs" {
    export const userJourneysPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "userJourneys";
        readonly artifactId: "journeys";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUserJourneys";
            readonly stepId: 12;
            readonly planId: "plan-user-journeys";
        };
        readonly data: {
            readonly journeys: readonly [{
                readonly journeyId: "registrarPedidoPos";
                readonly title: "Registrar pedido no POS rápido";
                readonly actor: "atendenteCaixa";
                readonly capabilityIds: readonly ["registrarPedidoPos"];
                readonly description: "O atendente abre o turno, registra um pedido rapidamente e finaliza a venda.";
                readonly steps: readonly [{
                    readonly intent: "Iniciar atendimento com o POS pronto";
                    readonly action: "Abrir o turno diário para liberar pedidos";
                    readonly entities: readonly ["DailyShift"];
                    readonly pageHint: "posRapido";
                    readonly outcome: "Turno diário fica aberto para registrar pedidos";
                }, {
                    readonly intent: "Montar o pedido do cliente";
                    readonly action: "Criar um pedido e adicionar itens e quantidades do cardápio";
                    readonly entities: readonly ["Order", "OrderItem", "MenuItem", "OrderUsecase"];
                    readonly pageHint: "posRapido";
                    readonly outcome: "Pedido é criado com itens selecionados";
                }, {
                    readonly intent: "Confirmar e enviar para a cozinha";
                    readonly action: "Revisar o pedido e confirmar o envio";
                    readonly entities: readonly ["Order", "OrderUsecase"];
                    readonly pageHint: "posRapido";
                    readonly outcome: "Pedido fica no status recebido e vai para a fila da cozinha";
                }, {
                    readonly intent: "Cancelar o pedido se o cliente desistir";
                    readonly action: "Selecionar o pedido e cancelar antes do preparo";
                    readonly entities: readonly ["Order", "OrderUsecase"];
                    readonly pageHint: "posRapido";
                    readonly outcome: "Pedido muda para status cancelado e não segue para preparo";
                }];
            }, {
                readonly journeyId: "atualizarStatusCozinha";
                readonly title: "Atualizar status do pedido na tela da cozinha";
                readonly actor: "cozinha";
                readonly capabilityIds: readonly ["atualizarStatusCozinha"];
                readonly description: "A cozinha organiza a fila de pedidos e atualiza os status até a entrega.";
                readonly steps: readonly [{
                    readonly intent: "Ver a fila de pedidos recebidos";
                    readonly action: "Abrir a tela da cozinha com a lista por status";
                    readonly entities: readonly ["Order"];
                    readonly pageHint: "telaCozinha";
                    readonly outcome: "Pedidos recebidos ficam visíveis para preparo";
                }, {
                    readonly intent: "Iniciar o preparo";
                    readonly action: "Mover o pedido para preparando";
                    readonly entities: readonly ["Order"];
                    readonly pageHint: "telaCozinha";
                    readonly outcome: "Pedido passa para status preparando";
                }, {
                    readonly intent: "Sinalizar que está pronto";
                    readonly action: "Atualizar o pedido para pronto";
                    readonly entities: readonly ["Order"];
                    readonly pageHint: "telaCozinha";
                    readonly outcome: "Pedido passa para status pronto e aguarda entrega";
                }, {
                    readonly intent: "Finalizar a entrega";
                    readonly action: "Marcar o pedido como entregue quando retirado";
                    readonly entities: readonly ["Order"];
                    readonly pageHint: "telaCozinha";
                    readonly outcome: "Pedido passa para status entregue";
                }, {
                    readonly intent: "Tratar pedido cancelado recebido na fila";
                    readonly action: "Remover ou marcar o pedido como cancelado";
                    readonly entities: readonly ["Order"];
                    readonly pageHint: "telaCozinha";
                    readonly outcome: "Pedido fica cancelado e sai da fila ativa";
                }];
            }, {
                readonly journeyId: "gerenciarCardapio";
                readonly title: "Gerenciar cardápio e categorias";
                readonly actor: "gerente";
                readonly capabilityIds: readonly ["gerenciarCardapio"];
                readonly description: "O gerente ajusta o cardápio para refletir disponibilidade e preços.";
                readonly steps: readonly [{
                    readonly intent: "Revisar o cardápio atual";
                    readonly action: "Abrir a área de gerenciamento de cardápio";
                    readonly entities: readonly ["MenuItem", "MenuCategory"];
                    readonly pageHint: "gerenciamentoCardapioEstoque";
                    readonly outcome: "Lista de itens e categorias fica disponível";
                }, {
                    readonly intent: "Criar ou editar itens";
                    readonly action: "Adicionar um novo item ou editar preço e descrição";
                    readonly entities: readonly ["MenuItem", "MenuCategory"];
                    readonly pageHint: "gerenciamentoCardapioEstoque";
                    readonly outcome: "Cardápio é atualizado";
                }, {
                    readonly intent: "Ajustar ingredientes vinculados";
                    readonly action: "Editar os ingredientes do item do cardápio";
                    readonly entities: readonly ["MenuItemIngredient", "MenuItem"];
                    readonly pageHint: "gerenciamentoCardapioEstoque";
                    readonly outcome: "Itens ficam alinhados ao controle de estoque";
                }, {
                    readonly intent: "Desativar item indisponível";
                    readonly action: "Marcar item como indisponível ou remover do cardápio ativo";
                    readonly entities: readonly ["MenuItem"];
                    readonly pageHint: "gerenciamentoCardapioEstoque";
                    readonly outcome: "Item não aparece no POS";
                }];
            }, {
                readonly journeyId: "gerenciarEstoque";
                readonly title: "Gerenciar estoque básico e ajustes";
                readonly actor: "gerente";
                readonly capabilityIds: readonly ["gerenciarEstoque"];
                readonly description: "O gerente acompanha níveis de estoque, registra ajustes e trata alertas de baixo estoque.";
                readonly steps: readonly [{
                    readonly intent: "Ver níveis atuais e alertas";
                    readonly action: "Abrir o painel de estoque e filtrar itens com baixo estoque";
                    readonly entities: readonly ["InventoryItem"];
                    readonly pageHint: "gerenciamentoCardapioEstoque";
                    readonly outcome: "Itens críticos ficam destacados para ação";
                }, {
                    readonly intent: "Registrar um ajuste de estoque";
                    readonly action: "Criar um ajuste com quantidade e motivo";
                    readonly entities: readonly ["InventoryAdjustment", "InventoryItem", "InventoryAdjustmentUsecase"];
                    readonly pageHint: "gerenciamentoCardapioEstoque";
                    readonly outcome: "Ajuste fica pendente para confirmação";
                }, {
                    readonly intent: "Confirmar o ajuste pendente";
                    readonly action: "Confirmar o ajuste criado";
                    readonly entities: readonly ["InventoryAdjustment", "InventoryAdjustmentUsecase"];
                    readonly pageHint: "gerenciamentoCardapioEstoque";
                    readonly outcome: "Ajuste passa para confirmado e o estoque é atualizado";
                }, {
                    readonly intent: "Cancelar um ajuste incorreto";
                    readonly action: "Cancelar o ajuste antes de confirmar";
                    readonly entities: readonly ["InventoryAdjustment", "InventoryAdjustmentUsecase"];
                    readonly pageHint: "gerenciamentoCardapioEstoque";
                    readonly outcome: "Ajuste passa para cancelado sem alterar estoque";
                }];
            }, {
                readonly journeyId: "fecharTurnoDiario";
                readonly title: "Fechar turno diário com consolidação";
                readonly actor: "gerente";
                readonly capabilityIds: readonly ["fecharTurnoDiario"];
                readonly description: "O gerente consolida as vendas e fecha o turno ao fim do expediente.";
                readonly steps: readonly [{
                    readonly intent: "Revisar pedidos do turno";
                    readonly action: "Abrir o relatório de fechamento e visualizar pedidos e totais";
                    readonly entities: readonly ["Order", "DailyShift", "ShiftCloseUsecase"];
                    readonly pageHint: "relatorioFechamentoTurno";
                    readonly outcome: "Consolidação do turno fica visível";
                }, {
                    readonly intent: "Conferir pendências antes do fechamento";
                    readonly action: "Identificar pedidos não entregues e resolver pendências";
                    readonly entities: readonly ["Order", "DailyShift"];
                    readonly pageHint: "relatorioFechamentoTurno";
                    readonly outcome: "Pendências são resolvidas para permitir fechamento";
                }, {
                    readonly intent: "Fechar o turno";
                    readonly action: "Confirmar o fechamento do turno diário";
                    readonly entities: readonly ["DailyShift", "ShiftClosingReport", "ShiftCloseUsecase"];
                    readonly pageHint: "relatorioFechamentoTurno";
                    readonly outcome: "Turno passa para fechado e relatório é gerado";
                }, {
                    readonly intent: "Cancelar o fechamento se encontrar erro";
                    readonly action: "Voltar e suspender o fechamento antes da confirmação final";
                    readonly entities: readonly ["DailyShift", "ShiftCloseUsecase"];
                    readonly pageHint: "relatorioFechamentoTurno";
                    readonly outcome: "Turno permanece aberto para ajustes";
                }];
            }, {
                readonly journeyId: "acompanharDashboard";
                readonly title: "Acompanhar dashboard de métricas do gerente";
                readonly actor: "gerente";
                readonly capabilityIds: readonly ["acompanharDashboard"];
                readonly description: "O gerente acompanha vendas, itens mais vendidos e alertas do dia.";
                readonly steps: readonly [{
                    readonly intent: "Acessar visão geral do dia";
                    readonly action: "Abrir o dashboard do gerente";
                    readonly entities: readonly ["DailyShift", "Order"];
                    readonly pageHint: "dashboard";
                    readonly outcome: "Métricas do dia são exibidas";
                }, {
                    readonly intent: "Analisar vendas e desempenho";
                    readonly action: "Navegar entre métricas de vendas do dia e itens mais vendidos";
                    readonly entities: readonly ["Order", "MenuItem"];
                    readonly pageHint: "dashboard";
                    readonly outcome: "Tendências de vendas ficam claras";
                }, {
                    readonly intent: "Ver alertas de estoque baixo";
                    readonly action: "Consultar o bloco de alertas de estoque baixo";
                    readonly entities: readonly ["InventoryItem"];
                    readonly pageHint: "dashboard";
                    readonly outcome: "Itens críticos são identificados para ação imediata";
                }];
            }];
        };
    };
    export default userJourneysPlan;
}
declare module "_102043_/l2/cafeFlow/posRapido.defs" {
    export const posRapidoPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "posRapido";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 62;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "posRapido";
                readonly pageName: "POS rápido";
                readonly actor: "atendenteCaixa";
                readonly purpose: "Registrar pedidos rapidamente, incluir itens e confirmar ou cancelar antes do preparo.";
                readonly capabilities: readonly ["registrarPedidoPos"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["orderLifecycle", "shiftLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [{
                    readonly name: "orderId";
                    readonly type: "Order";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult", "selectionFromList"];
                    readonly description: "Identificador do pedido para revisão, inclusão de itens ou cancelamento.";
                    readonly entityRef: "Order";
                    readonly fieldRef: "orderId";
                }, {
                    readonly name: "shiftId";
                    readonly type: "DailyShift";
                    readonly required: false;
                    readonly sources: readonly ["routeParam", "sessionContext"];
                    readonly description: "Turno diário aberto para registrar pedidos no POS.";
                    readonly entityRef: "DailyShift";
                    readonly fieldRef: "dailyShiftId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "telaCozinha";
                    readonly trigger: "Pedido confirmado e enviado para cozinha";
                    readonly description: "Após confirmação do pedido, encaminhar para a fila da cozinha.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Pedidos do turno";
                    readonly mode: "list";
                    readonly organisms: readonly [{
                        readonly organismName: "listaPedidosRecentes";
                        readonly purpose: "Listar pedidos recentes do turno para seleção rápida e revisão.";
                        readonly userActions: readonly ["selecionarPedido", "filtrarPorStatus"];
                        readonly requiredEntities: readonly ["Order", "DailyShift"];
                        readonly readsFields: readonly ["Order.orderId", "Order.status", "Order.serviceType", "Order.tableNumber", "Order.createdAt", "Order.updatedAt", "Order.dailyShiftId"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["orderStatusLifecycle", "shiftMustBeOpenForOrders"];
                    }];
                }, {
                    readonly sectionName: "Detalhes do pedido";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "detalhesPedido";
                        readonly purpose: "Exibir e editar os dados principais do pedido selecionado antes da confirmação.";
                        readonly userActions: readonly ["editarTipoAtendimento", "editarMesa", "adicionarObservacoes"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.orderId", "Order.status", "Order.serviceType", "Order.tableNumber", "Order.notes", "Order.createdAt", "Order.updatedAt", "Order.dailyShiftId"];
                        readonly writesFields: readonly ["Order.serviceType", "Order.tableNumber", "Order.notes"];
                        readonly rulesApplied: readonly ["orderStatusLifecycle"];
                    }];
                }, {
                    readonly sectionName: "Itens do pedido";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "itensPedido";
                        readonly purpose: "Registrar itens e quantidades do pedido em andamento.";
                        readonly userActions: readonly ["adicionarItem", "atualizarQuantidade", "removerItem"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.orderId", "Order.updatedAt"];
                        readonly writesFields: readonly ["Order.updatedAt"];
                        readonly rulesApplied: readonly ["inventoryDecrementPolicy"];
                    }];
                }, {
                    readonly sectionName: "Ações do pedido";
                    readonly mode: "confirm";
                    readonly organisms: readonly [{
                        readonly organismName: "acoesPedido";
                        readonly purpose: "Confirmar envio para cozinha ou cancelar o pedido quando necessário.";
                        readonly userActions: readonly ["confirmarPedido", "cancelarPedido"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.orderId", "Order.status"];
                        readonly writesFields: readonly ["Order.status", "Order.updatedAt"];
                        readonly rulesApplied: readonly ["orderStatusLifecycle", "shiftMustBeOpenForOrders"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listarPedidos";
                readonly purpose: "Listar pedidos recentes do turno para seleção no POS.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "shiftId";
                    readonly type: "DailyShift";
                    readonly required: false;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "limit";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "orders";
                    readonly type: "OrderSummary[]";
                }];
                readonly readsEntities: readonly ["Order", "DailyShift"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarPedidos"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "obterPedido";
                readonly purpose: "Carregar detalhes completos do pedido para revisão e edição.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "Order";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "Order";
                }, {
                    readonly name: "dailyShiftId";
                    readonly type: "DailyShift";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "serviceType";
                    readonly type: "string";
                }, {
                    readonly name: "tableNumber";
                    readonly type: "string";
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                }, {
                    readonly name: "createdAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["Order"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["obterPedido"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "criarPedido";
                readonly purpose: "Criar um novo pedido no POS vinculado ao turno aberto.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "shiftId";
                    readonly type: "DailyShift";
                    readonly required: false;
                }, {
                    readonly name: "serviceType";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "tableNumber";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "orderItems";
                    readonly type: "OrderItemInput[]";
                    readonly required: true;
                }, {
                    readonly name: "channel";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "Order";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "createdAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["DailyShift"];
                readonly writesEntities: readonly ["Order"];
                readonly readsTables: readonly ["daily_shift"];
                readonly writesTables: readonly ["order", "daily_sales_metrics", "top_selling_items_metrics"];
                readonly usecaseRefs: readonly ["criarPedido"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["orderStatusLifecycle", "shiftMustBeOpenForOrders", "inventoryDecrementPolicy"];
            }, {
                readonly commandName: "adicionarItemPedido";
                readonly purpose: "Adicionar itens e quantidades ao pedido em andamento.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "Order";
                    readonly required: true;
                }, {
                    readonly name: "orderItems";
                    readonly type: "OrderItemInput[]";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "Order";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["Order"];
                readonly writesEntities: readonly ["Order"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly ["order", "top_selling_items_metrics"];
                readonly usecaseRefs: readonly ["adicionarItemPedido"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["inventoryDecrementPolicy"];
            }, {
                readonly commandName: "atualizarStatusPedido";
                readonly purpose: "Cancelar o pedido quando solicitado pelo atendente.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "Order";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "motivo";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "Order";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["Order"];
                readonly writesEntities: readonly ["Order"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly ["order", "daily_sales_metrics"];
                readonly usecaseRefs: readonly ["atualizarStatusPedido"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["orderStatusLifecycle", "kitchenStatusUpdates"];
            }];
        };
    };
    export default posRapidoPagePlan;
}
declare module "_102043_/l2/cafeFlow/relatorioFechamentoTurno.defs" {
    export const relatorioFechamentoTurnoPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "relatorioFechamentoTurno";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 65;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "relatorioFechamentoTurno";
                readonly pageName: "Relatório de fechamento do turno";
                readonly actor: "gerente";
                readonly purpose: "Conferir pedidos, resolver pendências e fechar o turno diário com consolidação.";
                readonly capabilities: readonly ["fecharTurnoDiario"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["shiftLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly ["dailySalesMetricsAutomation"];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [{
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "query", "previousStepResult"];
                    readonly description: "Identificador do turno diário selecionado para conferência e fechamento.";
                    readonly entityRef: "DailyShift";
                    readonly fieldRef: "dailyShiftId";
                }, {
                    readonly name: "shiftDateStart";
                    readonly type: "date";
                    readonly required: false;
                    readonly sources: readonly ["query"];
                    readonly description: "Data inicial para filtrar turnos disponíveis.";
                }, {
                    readonly name: "shiftDateEnd";
                    readonly type: "date";
                    readonly required: false;
                    readonly sources: readonly ["query"];
                    readonly description: "Data final para filtrar turnos disponíveis.";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "dashboard";
                    readonly trigger: "Turno fechado com sucesso";
                    readonly description: "Após o fechamento e geração do relatório, retornar ao dashboard.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Seleção de turno";
                    readonly mode: "list";
                    readonly organisms: readonly [{
                        readonly organismName: "listaTurnosParaFechamento";
                        readonly purpose: "Listar turnos disponíveis para seleção e conferência.";
                        readonly userActions: readonly ["filtrarTurnosPorPeriodo", "selecionarTurno"];
                        readonly requiredEntities: readonly ["DailyShift"];
                        readonly readsFields: readonly ["DailyShift.dailyShiftId", "DailyShift.shiftDate", "DailyShift.status", "DailyShift.openedAt", "DailyShift.closedAt", "DailyShift.totalSalesAmount", "DailyShift.totalOrders"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Resumo e pendências do turno";
                    readonly mode: "read";
                    readonly organisms: readonly [{
                        readonly organismName: "detalhesTurnoConsolidacao";
                        readonly purpose: "Exibir detalhes do turno selecionado, totais e pendências antes do fechamento.";
                        readonly userActions: readonly ["visualizarTotais", "visualizarPendencias"];
                        readonly requiredEntities: readonly ["DailyShift", "Order"];
                        readonly readsFields: readonly ["DailyShift.dailyShiftId", "DailyShift.shiftDate", "DailyShift.status", "DailyShift.openedAt", "DailyShift.closedAt", "DailyShift.openingCashAmount", "DailyShift.closingCashAmount", "DailyShift.totalSalesAmount", "DailyShift.totalOrders", "DailyShift.notes"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["shiftCloseRequiresOrders"];
                    }];
                }, {
                    readonly sectionName: "Confirmação de fechamento";
                    readonly mode: "confirm";
                    readonly organisms: readonly [{
                        readonly organismName: "confirmacaoFechamentoTurno";
                        readonly purpose: "Confirmar o fechamento do turno diário e gerar o relatório final.";
                        readonly userActions: readonly ["confirmarFechamentoTurno"];
                        readonly requiredEntities: readonly ["DailyShift", "Order"];
                        readonly readsFields: readonly ["DailyShift.dailyShiftId", "DailyShift.status", "DailyShift.totalSalesAmount", "DailyShift.totalOrders"];
                        readonly writesFields: readonly ["DailyShift.status", "DailyShift.closedAt", "DailyShift.closingCashAmount", "DailyShift.totalSalesAmount", "DailyShift.totalOrders", "DailyShift.shiftClosingReportId"];
                        readonly rulesApplied: readonly ["shiftCloseRequiresOrders"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listarTurnos";
                readonly purpose: "Listar turnos disponíveis para fechamento.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "shiftDateStart";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "shiftDateEnd";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                }, {
                    readonly name: "shiftDate";
                    readonly type: "date";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "openedAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "closedAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "totalSalesAmount";
                    readonly type: "money";
                }, {
                    readonly name: "totalOrders";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["DailyShift"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["daily_shift"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarTurnos"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "obterTurno";
                readonly purpose: "Obter detalhes do turno e consolidação preliminar.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                }, {
                    readonly name: "shiftDate";
                    readonly type: "date";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "openedAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "closedAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "openingCashAmount";
                    readonly type: "money";
                }, {
                    readonly name: "closingCashAmount";
                    readonly type: "money";
                }, {
                    readonly name: "totalSalesAmount";
                    readonly type: "money";
                }, {
                    readonly name: "totalOrders";
                    readonly type: "number";
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                }, {
                    readonly name: "pendingOrdersCount";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["DailyShift", "Order"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["daily_shift", "order"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["obterTurno"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["shiftCloseRequiresOrders"];
            }, {
                readonly commandName: "fecharTurno";
                readonly purpose: "Confirmar fechamento do turno diário e gerar relatório.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "confirmacao";
                    readonly type: "boolean";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "closedAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "shiftClosingReportId";
                    readonly type: "string";
                }, {
                    readonly name: "totalSalesAmount";
                    readonly type: "money";
                }, {
                    readonly name: "totalOrders";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["DailyShift", "Order"];
                readonly writesEntities: readonly ["DailyShift"];
                readonly readsTables: readonly ["daily_shift", "order"];
                readonly writesTables: readonly ["daily_shift", "daily_sales_metrics"];
                readonly usecaseRefs: readonly ["fecharTurno"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["shiftCloseRequiresOrders"];
            }];
        };
    };
    export default relatorioFechamentoTurnoPagePlan;
}
declare module "_102043_/l2/cafeFlow/telaCozinha.defs" {
    export const telaCozinhaPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "telaCozinha";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 63;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "telaCozinha";
                readonly pageName: "Tela da cozinha";
                readonly actor: "cozinha";
                readonly purpose: "Organizar a fila de pedidos e atualizar o status até a entrega.";
                readonly capabilities: readonly ["atualizarStatusCozinha"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["orderLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [{
                    readonly name: "statusFiltro";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["queryParam", "userPreference"];
                    readonly description: "Filtro de status para a fila da cozinha (recebido, preparando, pronto).";
                    readonly entityRef: "Order";
                    readonly fieldRef: "status";
                }, {
                    readonly name: "periodo";
                    readonly type: "date";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Período para listar pedidos recentes.";
                    readonly entityRef: "Order";
                    readonly fieldRef: "createdAt";
                }, {
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Turno diário opcional para filtrar pedidos.";
                    readonly entityRef: "Order";
                    readonly fieldRef: "dailyShiftId";
                }];
                readonly navigationRefs: readonly [];
                readonly sections: readonly [{
                    readonly sectionName: "Filtros da fila";
                    readonly mode: "filter";
                    readonly organisms: readonly [{
                        readonly organismName: "FiltroStatusPeriodo";
                        readonly purpose: "Permitir filtrar pedidos por status, período e turno.";
                        readonly userActions: readonly ["filtrarPedidos", "limparFiltros"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.status", "Order.createdAt", "Order.dailyShiftId"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Fila de pedidos";
                    readonly mode: "list";
                    readonly organisms: readonly [{
                        readonly organismName: "ListaPedidosCozinha";
                        readonly purpose: "Exibir pedidos pendentes e em preparo com dados essenciais.";
                        readonly userActions: readonly ["selecionarPedido", "atualizarStatusPedido"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.orderId", "Order.status", "Order.serviceType", "Order.tableNumber", "Order.notes", "Order.createdAt", "Order.updatedAt"];
                        readonly writesFields: readonly ["Order.status", "Order.updatedAt"];
                        readonly rulesApplied: readonly ["orderStatusLifecycle", "kitchenStatusUpdates"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listarPedidosCozinha";
                readonly purpose: "Listar pedidos da fila da cozinha por status, período e turno.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "statusFiltro";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "periodo";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "serviceType";
                    readonly type: "string";
                }, {
                    readonly name: "tableNumber";
                    readonly type: "string";
                }, {
                    readonly name: "notes";
                    readonly type: "text";
                }, {
                    readonly name: "createdAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["Order"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarPedidosCozinha"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "atualizarStatusPedido";
                readonly purpose: "Mover pedido entre recebido, preparando, pronto e entregue.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "novoStatus";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["Order"];
                readonly writesEntities: readonly ["Order"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly ["order", "daily_sales_metrics"];
                readonly usecaseRefs: readonly ["atualizarStatusPedido"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["orderStatusLifecycle", "kitchenStatusUpdates"];
            }];
        };
    };
    export default telaCozinhaPagePlan;
}
declare module "_102043_/l2/cafeFlow/uiConsolidation.defs" {
    export const uiConsolidationPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "uiConsolidation";
        readonly artifactId: "uiConsolidation";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUiConsolidation";
            readonly stepId: 28;
            readonly planId: "plan-ui-consolidation";
        };
        readonly data: {
            readonly sharedComponents: readonly [];
            readonly namingFixes: readonly [{
                readonly pageId: "dashboard";
                readonly organismName: "Seletor de período e turno";
                readonly suggestedName: "seletorPeriodoTurno";
                readonly reason: "Padronizar para camelCase sem espaços.";
            }, {
                readonly pageId: "dashboard";
                readonly organismName: "Cards de métricas de vendas";
                readonly suggestedName: "cardsMetricasVendas";
                readonly reason: "Padronizar para camelCase sem espaços.";
            }, {
                readonly pageId: "dashboard";
                readonly organismName: "Ranking de itens mais vendidos";
                readonly suggestedName: "rankingItensMaisVendidos";
                readonly reason: "Padronizar para camelCase sem espaços.";
            }, {
                readonly pageId: "dashboard";
                readonly organismName: "Lista de alertas de estoque baixo";
                readonly suggestedName: "listaAlertasEstoqueBaixo";
                readonly reason: "Padronizar para camelCase sem espaços.";
            }, {
                readonly pageId: "gerenciamentoCardapioEstoque";
                readonly organismName: "ListaCategoriasCardapio";
                readonly suggestedName: "listaCategoriasCardapio";
                readonly reason: "Padronizar para camelCase iniciando com letra minúscula.";
            }, {
                readonly pageId: "gerenciamentoCardapioEstoque";
                readonly organismName: "EditorCategoriaCardapio";
                readonly suggestedName: "editorCategoriaCardapio";
                readonly reason: "Padronizar para camelCase iniciando com letra minúscula.";
            }, {
                readonly pageId: "gerenciamentoCardapioEstoque";
                readonly organismName: "SeletorItemCardapioMdm";
                readonly suggestedName: "seletorItemCardapioMdm";
                readonly reason: "Padronizar para camelCase iniciando com letra minúscula.";
            }, {
                readonly pageId: "gerenciamentoCardapioEstoque";
                readonly organismName: "ListaIngredientesItem";
                readonly suggestedName: "listaIngredientesItem";
                readonly reason: "Padronizar para camelCase iniciando com letra minúscula.";
            }, {
                readonly pageId: "gerenciamentoCardapioEstoque";
                readonly organismName: "EditorIngredienteItem";
                readonly suggestedName: "editorIngredienteItem";
                readonly reason: "Padronizar para camelCase iniciando com letra minúscula.";
            }, {
                readonly pageId: "gerenciamentoCardapioEstoque";
                readonly organismName: "ListaItensEstoque";
                readonly suggestedName: "listaItensEstoque";
                readonly reason: "Padronizar para camelCase iniciando com letra minúscula.";
            }, {
                readonly pageId: "gerenciamentoCardapioEstoque";
                readonly organismName: "EditorItemEstoque";
                readonly suggestedName: "editorItemEstoque";
                readonly reason: "Padronizar para camelCase iniciando com letra minúscula.";
            }, {
                readonly pageId: "gerenciamentoCardapioEstoque";
                readonly organismName: "ListaAjustesEstoque";
                readonly suggestedName: "listaAjustesEstoque";
                readonly reason: "Padronizar para camelCase iniciando com letra minúscula.";
            }, {
                readonly pageId: "gerenciamentoCardapioEstoque";
                readonly organismName: "CriarAjusteEstoque";
                readonly suggestedName: "criarAjusteEstoque";
                readonly reason: "Padronizar para camelCase iniciando com letra minúscula.";
            }, {
                readonly pageId: "gerenciamentoCardapioEstoque";
                readonly organismName: "ConfirmarAjusteEstoque";
                readonly suggestedName: "confirmarAjusteEstoque";
                readonly reason: "Padronizar para camelCase iniciando com letra minúscula.";
            }, {
                readonly pageId: "relatorioFechamentoTurno";
                readonly organismName: "listaTurnosParaFechamento";
                readonly suggestedName: "listaTurnosFechamento";
                readonly reason: "Padronizar para camelCase consistente e remover preposição redundante.";
            }, {
                readonly pageId: "relatorioFechamentoTurno";
                readonly organismName: "detalhesTurnoConsolidacao";
                readonly suggestedName: "detalhesTurnoConsolidacao";
                readonly reason: "Padronizar para camelCase consistente (já está, manter).";
            }, {
                readonly pageId: "relatorioFechamentoTurno";
                readonly organismName: "confirmacaoFechamentoTurno";
                readonly suggestedName: "confirmacaoFechamentoTurno";
                readonly reason: "Padronizar para camelCase consistente (já está, manter).";
            }, {
                readonly pageId: "telaCozinha";
                readonly organismName: "FiltroStatusPeriodo";
                readonly suggestedName: "filtroStatusPeriodo";
                readonly reason: "Padronizar para camelCase iniciando com letra minúscula.";
            }, {
                readonly pageId: "telaCozinha";
                readonly organismName: "ListaPedidosCozinha";
                readonly suggestedName: "listaPedidosCozinha";
                readonly reason: "Padronizar para camelCase iniciando com letra minúscula.";
            }];
            readonly notes: readonly ["Nenhum componente compartilhado identificado de forma conservadora."];
        };
    };
    export default uiConsolidationPlan;
}
declare module "_102043_/l2/cafeFlow/ontology/AiInsightRequest.defs" {
    export const AiInsightRequestEntityDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "ontologyEntity";
        readonly artifactId: "AiInsightRequest";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanEntityDefinition";
            readonly stepId: 42;
            readonly planId: "";
        };
        readonly data: {
            readonly entityDefinition: {
                readonly entityId: "AiInsightRequest";
                readonly title: "Solicitação de Insight IA";
                readonly description: "Pedido de geração de resumo de vendas ou sugestão de promoções.";
                readonly ownership: "moduleOwned";
                readonly kind: "entity";
                readonly fields: readonly [{
                    readonly fieldId: "aiInsightRequestId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único da solicitação de insight IA.";
                }, {
                    readonly fieldId: "insightType";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Tipo de insight solicitado.";
                    readonly enum: readonly ["resumoVendas", "sugestaoPromocoes"];
                }, {
                    readonly fieldId: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Status atual da solicitação de insight.";
                    readonly enum: readonly ["solicitado", "gerado", "falhou"];
                }, {
                    readonly fieldId: "dailyShiftId";
                    readonly type: "DailyShift";
                    readonly required: false;
                    readonly description: "Referência ao turno do dia relacionado à solicitação.";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação da solicitação.";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização da solicitação.";
                }];
                readonly statusEnum: readonly ["solicitado", "gerado", "falhou"];
                readonly lifecycleStates: readonly ["solicitado", "gerado", "falhou"];
                readonly rulesApplied: readonly ["aiInsightsUseMetrics"];
            };
        };
    };
    export default AiInsightRequestEntityDefinition;
}
declare module "_102043_/l2/cafeFlow/ontology/DailyShift.defs" {
    export const DailyShiftEntityDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "ontologyEntity";
        readonly artifactId: "DailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanEntityDefinition";
            readonly stepId: 40;
            readonly planId: "";
        };
        readonly data: {
            readonly entityDefinition: {
                readonly entityId: "DailyShift";
                readonly title: "Turno Diário";
                readonly description: "Registro de abertura e fechamento do turno com consolidação de vendas.";
                readonly ownership: "moduleOwned";
                readonly kind: "core";
                readonly fields: readonly [{
                    readonly fieldId: "dailyShiftId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do turno diário.";
                }, {
                    readonly fieldId: "shiftDate";
                    readonly type: "date";
                    readonly required: true;
                    readonly description: "Data do turno diário.";
                }, {
                    readonly fieldId: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Status do turno diário.";
                    readonly enum: readonly ["aberto", "fechado"];
                }, {
                    readonly fieldId: "openedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de abertura do turno.";
                }, {
                    readonly fieldId: "closedAt";
                    readonly type: "datetime";
                    readonly required: false;
                    readonly description: "Data e hora de fechamento do turno.";
                }, {
                    readonly fieldId: "openingCashAmount";
                    readonly type: "money";
                    readonly required: false;
                    readonly description: "Valor de caixa informado na abertura do turno.";
                }, {
                    readonly fieldId: "closingCashAmount";
                    readonly type: "money";
                    readonly required: false;
                    readonly description: "Valor de caixa informado no fechamento do turno.";
                }, {
                    readonly fieldId: "totalSalesAmount";
                    readonly type: "money";
                    readonly required: false;
                    readonly description: "Total de vendas consolidadas no turno.";
                }, {
                    readonly fieldId: "totalOrders";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Quantidade total de pedidos no turno.";
                }, {
                    readonly fieldId: "notes";
                    readonly type: "text";
                    readonly required: false;
                    readonly description: "Observações gerais do turno.";
                }, {
                    readonly fieldId: "shiftClosingReportId";
                    readonly type: "ShiftClosingReport";
                    readonly required: false;
                    readonly description: "Referência ao relatório de fechamento do turno.";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do registro.";
                }];
                readonly statusEnum: readonly ["aberto", "fechado"];
                readonly rulesApplied: readonly ["shiftMustBeOpenForOrders", "shiftCloseRequiresOrders"];
            };
        };
    };
    export default DailyShiftEntityDefinition;
}
declare module "_102043_/l2/cafeFlow/ontology/InventoryAdjustment.defs" {
    export const InventoryAdjustmentEntityDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "ontologyEntity";
        readonly artifactId: "InventoryAdjustment";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanEntityDefinition";
            readonly stepId: 38;
            readonly planId: "";
        };
        readonly data: {
            readonly entityDefinition: {
                readonly entityId: "InventoryAdjustment";
                readonly title: "Ajuste de Estoque";
                readonly description: "Registro operacional de baixa ou ajuste de estoque manual.";
                readonly ownership: "moduleOwned";
                readonly kind: "entity";
                readonly fields: readonly [{
                    readonly fieldId: "inventoryAdjustmentId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do ajuste de estoque.";
                }, {
                    readonly fieldId: "inventoryItemId";
                    readonly type: "InventoryItem";
                    readonly required: true;
                    readonly description: "Item de estoque ao qual o ajuste se aplica.";
                }, {
                    readonly fieldId: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Status do ajuste de estoque.";
                    readonly enum: readonly ["pendente", "confirmado", "cancelado"];
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do registro.";
                }];
                readonly statusEnum: readonly ["pendente", "confirmado", "cancelado"];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default InventoryAdjustmentEntityDefinition;
}
declare module "_102043_/l2/cafeFlow/ontology/InventoryAdjustmentUsecase.defs" {
    export const InventoryAdjustmentUsecaseEntityDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "ontologyEntity";
        readonly artifactId: "InventoryAdjustmentUsecase";
        readonly moduleName: "cafeFlow";
        readonly status: "incomplete";
        readonly source: {
            readonly agentName: "agentPlanEntityDefinition";
            readonly stepId: 39;
            readonly planId: "";
        };
        readonly data: {
            readonly entityDefinition: {
                readonly entityId: "InventoryAdjustmentUsecase";
                readonly title: "Ajuste de Estoque (Caso de Uso)";
                readonly description: "Entidade operacional para comandos de ajuste/baixa de estoque.";
                readonly ownership: "moduleOwned";
                readonly fields: readonly [{
                    readonly fieldId: "inventoryAdjustmentUsecaseId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador do caso de uso de ajuste de estoque.";
                }, {
                    readonly fieldId: "commandType";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Tipo de comando de estoque executado (ajuste ou baixa).";
                    readonly enum: readonly ["ajuste", "baixa"];
                }];
                readonly rulesApplied: readonly ["inventoryDecrementPolicy"];
            };
            readonly pendingQuestions: readonly ["Quais são todos os atributos obrigatórios deste caso de uso (ex.: motivo, quantidade, item-alvo, origem do comando, usuário responsável)?", "Este caso de uso é persistido? Se sim, devo incluir createdAt/updatedAt?", "Há estados/lifecycle (ex.: rascunho, validado, executado, cancelado) para este caso de uso?", "Existem relações obrigatórias com outras entidades (ex.: InventoryAdjustment, InventoryItem, Order, DailyShift) que devem virar campos de referência?"];
        };
    };
    export default InventoryAdjustmentUsecaseEntityDefinition;
}
declare module "_102043_/l2/cafeFlow/ontology/InventoryItem.defs" {
    export const InventoryItemEntityDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "ontologyEntity";
        readonly artifactId: "InventoryItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanEntityDefinition";
            readonly stepId: 40;
            readonly planId: "";
        };
        readonly data: {
            readonly entityDefinition: {
                readonly entityId: "InventoryItem";
                readonly title: "Item de Estoque";
                readonly description: "Insumo ou item de estoque com nível mínimo e quantidade disponível.";
                readonly ownership: "moduleOwned";
                readonly fields: readonly [{
                    readonly fieldId: "inventoryItemId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do item de estoque.";
                }, {
                    readonly fieldId: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Nome do insumo ou item de estoque.";
                }, {
                    readonly fieldId: "quantityAvailable";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade disponível em estoque.";
                }, {
                    readonly fieldId: "minimumLevel";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Nível mínimo aceitável para o estoque.";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do registro.";
                }];
                readonly rulesApplied: readonly ["inventoryLowStockAlert", "inventoryDecrementPolicy"];
            };
        };
    };
    export default InventoryItemEntityDefinition;
}
declare module "_102043_/l2/cafeFlow/ontology/MenuCategory.defs" {
    export const MenuCategoryEntityDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "ontologyEntity";
        readonly artifactId: "MenuCategory";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanEntityDefinition";
            readonly stepId: 39;
            readonly planId: "";
        };
        readonly data: {
            readonly entityDefinition: {
                readonly entityId: "MenuCategory";
                readonly title: "Categoria do Cardápio";
                readonly description: "Agrupamento de itens do cardápio para navegação rápida no POS.";
                readonly ownership: "moduleOwned";
                readonly fields: readonly [{
                    readonly fieldId: "menuCategoryId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único da categoria";
                }, {
                    readonly fieldId: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Nome da categoria exibido no POS";
                }, {
                    readonly fieldId: "description";
                    readonly type: "text";
                    readonly required: false;
                    readonly description: "Descrição opcional da categoria";
                }, {
                    readonly fieldId: "sortOrder";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Ordem de exibição no POS (menor valor aparece primeiro)";
                }, {
                    readonly fieldId: "color";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Cor hexadecimal para identificação visual no POS";
                }, {
                    readonly fieldId: "isActive";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly description: "Indica se a categoria está ativa e visível no cardápio";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do registro";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do registro";
                }];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default MenuCategoryEntityDefinition;
}
declare module "_102043_/l2/cafeFlow/ontology/MenuItem.defs" {
    export const MenuItemEntityDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "ontologyEntity";
        readonly artifactId: "MenuItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanEntityDefinition";
            readonly stepId: 38;
            readonly planId: "";
        };
        readonly data: {
            readonly entityDefinition: {
                readonly entityId: "MenuItem";
                readonly title: "Item do Cardápio";
                readonly description: "Produto vendido no POS com preço e vínculo a ingredientes/estoque.";
                readonly ownership: "mdmOwned";
                readonly fields: readonly [{
                    readonly fieldId: "menuItemId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do item do cardápio.";
                }, {
                    readonly fieldId: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Nome do item exibido no cardápio.";
                }, {
                    readonly fieldId: "description";
                    readonly type: "text";
                    readonly required: false;
                    readonly description: "Descrição detalhada do item.";
                }, {
                    readonly fieldId: "price";
                    readonly type: "money";
                    readonly required: true;
                    readonly description: "Preço de venda do item.";
                }, {
                    readonly fieldId: "menuCategoryId";
                    readonly type: "MenuCategory";
                    readonly required: true;
                    readonly description: "Categoria à qual o item do cardápio pertence.";
                }, {
                    readonly fieldId: "isActive";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly description: "Indica se o item está ativo para venda.";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do registro.";
                }];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default MenuItemEntityDefinition;
}
declare module "_102043_/l2/cafeFlow/ontology/MenuItemIngredient.defs" {
    export const MenuItemIngredientEntityDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "ontologyEntity";
        readonly artifactId: "MenuItemIngredient";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanEntityDefinition";
            readonly stepId: 41;
            readonly planId: "";
        };
        readonly data: {
            readonly entityDefinition: {
                readonly entityId: "MenuItemIngredient";
                readonly title: "Ingrediente do Item do Cardápio";
                readonly description: "Vínculo entre item do cardápio e itens de estoque para controle de ingredientes.";
                readonly ownership: "moduleOwned";
                readonly fields: readonly [{
                    readonly fieldId: "id";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do vínculo ingrediente-cardápio";
                }, {
                    readonly fieldId: "menuItemId";
                    readonly type: "MenuItem";
                    readonly required: true;
                    readonly description: "Referência ao item do cardápio";
                }, {
                    readonly fieldId: "inventoryItemId";
                    readonly type: "InventoryItem";
                    readonly required: true;
                    readonly description: "Referência ao item de estoque utilizado como ingrediente";
                }, {
                    readonly fieldId: "quantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade necessária do ingrediente para o preparo do item";
                }, {
                    readonly fieldId: "unit";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Unidade de medida (ex: g, ml, unidade, colher)";
                }, {
                    readonly fieldId: "isOptional";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly description: "Indica se o ingrediente é opcional ou pode ser removido do item";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do registro";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do registro";
                }];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default MenuItemIngredientEntityDefinition;
}
declare module "_102043_/l2/cafeFlow/ontology/Order.defs" {
    export const OrderEntityDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "ontologyEntity";
        readonly artifactId: "Order";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanEntityDefinition";
            readonly stepId: 42;
            readonly planId: "";
        };
        readonly data: {
            readonly entityDefinition: {
                readonly entityId: "Order";
                readonly title: "Pedido";
                readonly description: "Compromisso de venda (mesa ou takeout) com itens e status de preparo.";
                readonly ownership: "moduleOwned";
                readonly kind: "entity";
                readonly fields: readonly [{
                    readonly fieldId: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do pedido.";
                }, {
                    readonly fieldId: "dailyShiftId";
                    readonly type: "DailyShift";
                    readonly required: true;
                    readonly description: "Referência ao turno diário ao qual o pedido pertence.";
                }, {
                    readonly fieldId: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Status atual do pedido.";
                    readonly enum: readonly ["recebido", "preparando", "pronto", "entregue", "cancelado"];
                }, {
                    readonly fieldId: "serviceType";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Tipo de atendimento do pedido (mesa ou takeout).";
                    readonly enum: readonly ["mesa", "takeout"];
                }, {
                    readonly fieldId: "tableNumber";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Número/identificador da mesa quando o atendimento é em mesa.";
                }, {
                    readonly fieldId: "notes";
                    readonly type: "text";
                    readonly required: false;
                    readonly description: "Observações gerais do pedido.";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do pedido.";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do pedido.";
                }];
                readonly statusEnum: readonly ["recebido", "preparando", "pronto", "entregue", "cancelado"];
                readonly lifecycleStates: readonly ["recebido", "preparando", "pronto", "entregue", "cancelado"];
                readonly rulesApplied: readonly ["orderStatusLifecycle", "kitchenStatusUpdates", "shiftMustBeOpenForOrders", "inventoryDecrementPolicy"];
            };
        };
    };
    export default OrderEntityDefinition;
}
declare module "_102043_/l2/cafeFlow/ontology/OrderItem.defs" {
    export const OrderItemEntityDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "ontologyEntity";
        readonly artifactId: "OrderItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanEntityDefinition";
            readonly stepId: 38;
            readonly planId: "";
        };
        readonly data: {
            readonly entityDefinition: {
                readonly entityId: "OrderItem";
                readonly title: "Item do Pedido";
                readonly description: "Itens do cardápio associados a um pedido com quantidade e observações.";
                readonly ownership: "moduleOwned";
                readonly fields: readonly [{
                    readonly fieldId: "orderItemId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do item do pedido.";
                }, {
                    readonly fieldId: "orderId";
                    readonly type: "Order";
                    readonly required: true;
                    readonly description: "Referência ao pedido ao qual este item pertence.";
                }, {
                    readonly fieldId: "menuItemId";
                    readonly type: "MenuItem";
                    readonly required: true;
                    readonly description: "Referência ao item do cardápio selecionado.";
                }, {
                    readonly fieldId: "quantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade do item no pedido.";
                }, {
                    readonly fieldId: "unitPrice";
                    readonly type: "money";
                    readonly required: true;
                    readonly description: "Preço unitário aplicado no momento do pedido.";
                }, {
                    readonly fieldId: "itemNote";
                    readonly type: "text";
                    readonly required: false;
                    readonly description: "Observações ou instruções especiais para o item.";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do item do pedido.";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do item do pedido.";
                }];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default OrderItemEntityDefinition;
}
declare module "_102043_/l2/cafeFlow/ontology/OrderUsecase.defs" {
    export const OrderUsecaseEntityDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "ontologyEntity";
        readonly artifactId: "OrderUsecase";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanEntityDefinition";
            readonly stepId: 40;
            readonly planId: "";
        };
        readonly data: {
            readonly entityDefinition: {
                readonly entityId: "OrderUsecase";
                readonly title: "Pedido (Caso de Uso)";
                readonly description: "Entidade operacional para comandos de criação e atualização de pedidos.";
                readonly ownership: "moduleOwned";
                readonly kind: "usecase";
                readonly fields: readonly [{
                    readonly fieldId: "orderUsecaseId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do caso de uso de pedido.";
                }, {
                    readonly fieldId: "orderId";
                    readonly type: "Order";
                    readonly required: false;
                    readonly description: "Referência ao pedido alvo quando aplicável.";
                }, {
                    readonly fieldId: "operation";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Operação solicitada sobre o pedido.";
                }, {
                    readonly fieldId: "payload";
                    readonly type: "text";
                    readonly required: false;
                    readonly description: "Dados do comando para criação ou atualização do pedido.";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do caso de uso.";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do caso de uso.";
                }];
                readonly rulesApplied: readonly ["kitchenStatusUpdates", "shiftMustBeOpenForOrders"];
            };
        };
    };
    export default OrderUsecaseEntityDefinition;
}
declare module "_102043_/l2/cafeFlow/ontology/ShiftCloseUsecase.defs" {
    export const ShiftCloseUsecaseEntityDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "ontologyEntity";
        readonly artifactId: "ShiftCloseUsecase";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanEntityDefinition";
            readonly stepId: 38;
            readonly planId: "";
        };
        readonly data: {
            readonly entityDefinition: {
                readonly entityId: "ShiftCloseUsecase";
                readonly title: "Fechamento de Turno (Caso de Uso)";
                readonly description: "Entidade operacional para o processo de fechamento diário.";
                readonly ownership: "moduleOwned";
                readonly kind: "usecase";
                readonly fields: readonly [{
                    readonly fieldId: "shiftCloseUsecaseId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do caso de uso de fechamento de turno.";
                }, {
                    readonly fieldId: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Status atual do processo de fechamento de turno.";
                    readonly enum: readonly ["aberto", "emProgresso", "concluido", "falhou", "cancelado"];
                }, {
                    readonly fieldId: "startedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de início do fechamento de turno.";
                }, {
                    readonly fieldId: "completedAt";
                    readonly type: "datetime";
                    readonly required: false;
                    readonly description: "Data e hora de conclusão do fechamento de turno.";
                }, {
                    readonly fieldId: "notes";
                    readonly type: "text";
                    readonly required: false;
                    readonly description: "Observações gerais registradas durante o fechamento do turno.";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do registro.";
                }];
                readonly statusEnum: readonly ["aberto", "emProgresso", "concluido", "falhou", "cancelado"];
                readonly lifecycleStates: readonly ["aberto", "emProgresso", "concluido", "falhou", "cancelado"];
                readonly rulesApplied: readonly ["shiftCloseRequiresOrders"];
            };
        };
    };
    export default ShiftCloseUsecaseEntityDefinition;
}
declare module "_102043_/l2/cafeFlow/ontology/ShiftClosingReport.defs" {
    export const ShiftClosingReportEntityDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "ontologyEntity";
        readonly artifactId: "ShiftClosingReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanEntityDefinition";
            readonly stepId: 42;
            readonly planId: "";
        };
        readonly data: {
            readonly entityDefinition: {
                readonly entityId: "ShiftClosingReport";
                readonly title: "Relatório de Fechamento de Turno";
                readonly description: "Resumo consolidado do turno diário para conferência do gerente.";
                readonly ownership: "moduleOwned";
                readonly fields: readonly [{
                    readonly fieldId: "shiftClosingReportId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do relatório de fechamento do turno.";
                }, {
                    readonly fieldId: "dailyShiftId";
                    readonly type: "DailyShift";
                    readonly required: true;
                    readonly description: "Turno diário ao qual este relatório de fechamento se refere.";
                }, {
                    readonly fieldId: "totalSales";
                    readonly type: "money";
                    readonly required: true;
                    readonly description: "Valor total de vendas consolidadas no período do turno.";
                }, {
                    readonly fieldId: "totalOrders";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade total de pedidos consolidados no turno.";
                }, {
                    readonly fieldId: "totalItems";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Quantidade total de itens vendidos no turno.";
                }, {
                    readonly fieldId: "cashTotal";
                    readonly type: "money";
                    readonly required: false;
                    readonly description: "Total recebido em dinheiro no turno.";
                }, {
                    readonly fieldId: "cardTotal";
                    readonly type: "money";
                    readonly required: false;
                    readonly description: "Total recebido em cartão no turno.";
                }, {
                    readonly fieldId: "pixTotal";
                    readonly type: "money";
                    readonly required: false;
                    readonly description: "Total recebido via PIX no turno.";
                }, {
                    readonly fieldId: "cancellationsTotal";
                    readonly type: "money";
                    readonly required: false;
                    readonly description: "Valor total de cancelamentos estornados no turno.";
                }, {
                    readonly fieldId: "notes";
                    readonly type: "text";
                    readonly required: false;
                    readonly description: "Observações do gerente sobre o fechamento do turno.";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do relatório.";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do relatório.";
                }];
                readonly rulesApplied: readonly ["shiftCloseRequiresOrders"];
            };
        };
    };
    export default ShiftClosingReportEntityDefinition;
}
