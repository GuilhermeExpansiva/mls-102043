/// <mls fileReference="_102043_/l2/cafeFlow/kitchenQueue.defs.ts" enhancement="_blank"/>

export const kitchenQueuePagePlan = {
  "schemaVersion": "2026-06-06",
  "artifactType": "page",
  "artifactId": "kitchenQueue",
  "moduleName": "cafeFlow",
  "status": "draft",
  "source": {
    "agentName": "agentPlanPageDefinition",
    "stepId": 81,
    "planId": ""
  },
  "data": {
    "pageDefinition": {
      "pageId": "kitchenQueue",
      "pageName": "Fila da Cozinha",
      "actor": "cozinha",
      "purpose": "Acompanhar pedidos pendentes e atualizar status de preparo, pronto e entregue.",
      "capabilities": [
        "acompanharFilaCozinha",
        "atualizarStatusPedido"
      ],
      "flowRefs": {
        "experienceFlows": [],
        "entityLifecycles": [
          "orderLifecycle"
        ],
        "taskWorkflows": [],
        "automations": []
      },
      "pluginRefs": [],
      "mdmRefs": [
        "ingredient"
      ],
      "pageInputs": [],
      "navigationRefs": [
        {
          "direction": "inbound",
          "pageId": "posOrderConfirm",
          "trigger": "novo pedido confirmado",
          "description": "Pedido confirmado no POS entra na fila da cozinha."
        }
      ],
      "sections": [
        {
          "sectionName": "Fila de pedidos",
          "mode": "view",
          "organisms": [
            {
              "organismName": "KitchenQueueList",
              "purpose": "Listar pedidos em aberto com status e prioridade para acompanhamento rápido da cozinha.",
              "userActions": [
                "selecionarPedido",
                "filtrarPorStatus",
                "ordenarPorTempo"
              ],
              "requiredEntities": [
                "orderAggregateEntity"
              ],
              "readsFields": [
                "Order.orderNumber",
                "Order.orderType",
                "Order.tableNumber",
                "Order.status",
                "Order.kitchenPriority",
                "Order.itemCount",
                "Order.createdAt",
                "Order.updatedAt"
              ],
              "writesFields": [],
              "rulesApplied": [
                "rule-order-status-transition"
              ]
            }
          ]
        },
        {
          "sectionName": "Detalhes e atualização de status",
          "mode": "edit",
          "organisms": [
            {
              "organismName": "OrderDetailsPanel",
              "purpose": "Exibir detalhes do pedido selecionado com itens e horários relevantes.",
              "userActions": [
                "visualizarDetalhesPedido"
              ],
              "requiredEntities": [
                "orderAggregateEntity"
              ],
              "readsFields": [
                "Order.orderNumber",
                "Order.orderType",
                "Order.tableNumber",
                "Order.status",
                "Order.itemCount",
                "Order.totalAmount",
                "Order.createdAt",
                "Order.updatedAt",
                "Order.closedAt"
              ],
              "writesFields": [],
              "rulesApplied": [
                "rule-order-status-transition"
              ]
            },
            {
              "organismName": "OrderStatusActions",
              "purpose": "Permitir transicionar o status do pedido conforme o fluxo da cozinha.",
              "userActions": [
                "updateOrderStatusPreparing",
                "updateOrderStatusReady",
                "updateOrderStatusDelivered"
              ],
              "requiredEntities": [
                "orderAggregateEntity"
              ],
              "readsFields": [
                "Order.status"
              ],
              "writesFields": [
                "Order.status",
                "Order.updatedAt",
                "Order.closedAt"
              ],
              "rulesApplied": [
                "rule-order-status-transition",
                "rule-stock-deduct-by-ingredient"
              ]
            }
          ]
        }
      ]
    },
    "bffCommands": [
      {
        "commandName": "getKitchenQueue",
        "purpose": "Listar pedidos aguardando preparo ou finalização para exibição na fila da cozinha.",
        "kind": "query",
        "input": {
          "statusFilter": [
            "Novo",
            "Em preparo",
            "Pronto"
          ],
          "createdAfter": "timestamp?",
          "limit": "number?",
          "offset": "number?"
        },
        "output": {
          "orders": [
            {
              "orderId": "uuid",
              "orderNumber": "string",
              "orderType": "string",
              "tableNumber": "string?",
              "status": "string",
              "kitchenPriority": "string?",
              "itemCount": "number",
              "totalAmount": "number",
              "createdAt": "timestamp",
              "updatedAt": "timestamp"
            }
          ]
        },
        "readsEntities": [
          "orderAggregateEntity"
        ],
        "writesEntities": [],
        "readsTables": [
          "order_aggregate"
        ],
        "writesTables": [],
        "usecaseRefs": [
          "usecaseAtualizarStatusPedido"
        ],
        "layerContract": {
          "controllerLayer": "layer_2_controllers",
          "mustCallLayer": "layer_3_usecases",
          "directTableAccessForbidden": true
        },
        "rulesApplied": [
          "rule-order-status-transition"
        ]
      },
      {
        "commandName": "updateOrderStatus",
        "purpose": "Atualizar status do pedido pela cozinha conforme a sequência permitida.",
        "kind": "command",
        "input": {
          "orderId": "uuid",
          "newStatus": "string",
          "action": "updateOrderStatusPreparing|updateOrderStatusReady|updateOrderStatusDelivered"
        },
        "output": {
          "order": {
            "orderId": "uuid",
            "status": "string",
            "updatedAt": "timestamp",
            "closedAt": "timestamp?"
          }
        },
        "readsEntities": [
          "orderAggregateEntity"
        ],
        "writesEntities": [
          "orderAggregateEntity",
          "stockItemEntity"
        ],
        "readsTables": [
          "order_aggregate"
        ],
        "writesTables": [
          "order_aggregate"
        ],
        "usecaseRefs": [
          "usecaseAtualizarStatusPedido",
          "usecaseBaixarEstoqueIngredientes"
        ],
        "layerContract": {
          "controllerLayer": "layer_2_controllers",
          "mustCallLayer": "layer_3_usecases",
          "directTableAccessForbidden": true
        },
        "rulesApplied": [
          "rule-order-status-transition",
          "rule-stock-deduct-by-ingredient"
        ]
      }
    ]
  }
} as const;

export default kitchenQueuePagePlan;
